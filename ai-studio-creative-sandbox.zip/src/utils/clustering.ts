import { Track } from '../data/tracks';

export interface Cluster {
  id: number;
  name: string;
  emoji: string;
  description: string;
  bestFor: string;
  color: string; // Tailwind color classes
  centroid: { [key: string]: number };
  tracks: Track[];
}

// Map index to visually distinct colors
export const CLUSTER_COLORS = [
  '#1DB954', // Spotify Green
  '#3b82f6', // Blue
  '#ec4899', // Pink
  '#eab308', // Yellow
  '#a855f7', // Purple
  '#f97316', // Orange
];

export const CLUSTER_BORDER_COLORS = [
  'border-emerald-500/20 text-emerald-400 bg-emerald-500/10',
  'border-blue-500/20 text-blue-400 bg-blue-500/10',
  'border-pink-500/20 text-pink-400 bg-pink-500/10',
  'border-yellow-500/20 text-yellow-400 bg-yellow-500/10',
  'border-purple-500/20 text-purple-400 bg-purple-500/10',
  'border-orange-500/20 text-orange-400 bg-orange-500/10',
];

// Helper to normalize track features to a 0-1 scale
export function getFeatureValue(track: Track, feature: string): number {
  if (feature === 'tempo') {
    // Normalize Tempo (range roughly 60 to 180)
    return Math.max(0, Math.min(1, (track.tempo - 60) / 120));
  }
  return (track as any)[feature] || 0;
}

// Distance helper
function euclideanDistance(v1: number[], v2: number[]): number {
  return Math.sqrt(v1.reduce((sum, val, idx) => sum + Math.pow(val - v2[idx], 2), 0));
}

// K-Means clustering implementation
export function runKMeans(
  tracks: Track[],
  k: number,
  selectedFeatures: string[],
  maxIterations: number = 20
): Cluster[] {
  if (tracks.length === 0 || selectedFeatures.length === 0 || k <= 0) return [];

  // 1. Initialize centroids using simple K-Means++ or spaced distribution
  // For repeatability, let's seed selection deterministically or pick spaced indexes
  const centroids: number[][] = [];
  const step = Math.floor(tracks.length / k);
  for (let i = 0; i < k; i++) {
    const trackIndex = Math.min(tracks.length - 1, i * step + Math.floor(step / 2));
    const track = tracks[trackIndex];
    centroids.push(selectedFeatures.map(f => getFeatureValue(track, f)));
  }

  let assignments = new Array(tracks.length).fill(-1);
  let iteration = 0;
  let converged = false;

  while (!converged && iteration < maxIterations) {
    converged = true;
    const newAssignments = [];

    // Assign tracks to closest centroid
    for (let t = 0; t < tracks.length; t++) {
      const track = tracks[t];
      const trackVector = selectedFeatures.map(f => getFeatureValue(track, f));
      
      let minDistance = Infinity;
      let closestCluster = 0;

      for (let c = 0; c < k; c++) {
        const dist = euclideanDistance(trackVector, centroids[c]);
        if (dist < minDistance) {
          minDistance = dist;
          closestCluster = c;
        }
      }

      newAssignments.push(closestCluster);
      if (newAssignments[t] !== assignments[t]) {
        converged = false;
      }
    }

    assignments = newAssignments;

    // Recompute centroids
    const clusterSums = Array.from({ length: k }, () => new Array(selectedFeatures.length).fill(0));
    const clusterCounts = new Array(k).fill(0);

    for (let t = 0; t < tracks.length; t++) {
      const clusterIdx = assignments[t];
      const trackVector = selectedFeatures.map(f => getFeatureValue(tracks[t], f));
      clusterCounts[clusterIdx]++;
      for (let f = 0; f < selectedFeatures.length; f++) {
        clusterSums[clusterIdx][f] += trackVector[f];
      }
    }

    for (let c = 0; c < k; c++) {
      if (clusterCounts[c] > 0) {
        centroids[c] = centroids[c].map((_, fIdx) => clusterSums[c][fIdx] / clusterCounts[c]);
      }
    }

    iteration++;
  }

  // Map K-Means results to Cluster objects
  const clusters: Cluster[] = Array.from({ length: k }, (_, i) => {
    const clusterTracks = tracks.filter((_, tIdx) => assignments[tIdx] === i);
    
    // Compute centroid averages for ALL available features (not just the clustered ones)
    const centroidStats: { [key: string]: number } = {};
    const featuresToProfile = ['danceability', 'energy', 'valence', 'acousticness', 'tempo'];
    
    featuresToProfile.forEach(feature => {
      if (clusterTracks.length === 0) {
        centroidStats[feature] = 0;
        return;
      }
      const sum = clusterTracks.reduce((s, t) => {
        if (feature === 'tempo') return s + t.tempo;
        return s + (t as any)[feature];
      }, 0);
      centroidStats[feature] = sum / clusterTracks.length;
    });

    // Profile the cluster to give it an appropriate pre-AI backup label
    const profile = autoProfileCluster(centroidStats, i);

    return {
      id: i,
      name: profile.name,
      emoji: profile.emoji,
      description: profile.description,
      bestFor: profile.bestFor,
      color: CLUSTER_COLORS[i % CLUSTER_COLORS.length],
      centroid: centroidStats,
      tracks: clusterTracks,
    };
  });

  return clusters;
}

// Fallback rule-based profiling in case the user doesn't call Gemini or keys are missing
function autoProfileCluster(stats: { [key: string]: number }, index: number) {
  const { danceability, energy, valence, acousticness, tempo } = stats;

  // Rule matrix
  if (acousticness > 0.6) {
    if (energy < 0.25) {
      return {
        name: 'Zen Sanctuary',
        emoji: '🧘',
        description: 'Ultra-low energy, completely acoustic arrangements designed for absolute focus, meditation, and pure tranquility.',
        bestFor: 'Studying, Sleep, Mindfulness Meditation'
      };
    }
    return {
      name: 'Acoustic Coffeehouse',
      emoji: '☕',
      description: 'Warm, organic vibes dominated by acoustic instruments, singer-songwriters, and gentle, soulful melodies.',
      bestFor: 'Morning Coffee, Soft Focus, Rainy Days'
    };
  }

  if (energy > 0.7) {
    if (danceability > 0.7) {
      return {
        name: 'Club Pulse',
        emoji: '🔥',
        description: 'High-intensity electronic beats, rhythmic pop tracks, and high-energy anthems tuned for the dancefloor.',
        bestFor: 'Cardio Workouts, Party Starters, High-Energy Moods'
      };
    }
    return {
      name: 'Stadium Rock & Metal',
      emoji: '🎸',
      description: 'Loud, energetic instrumentation, electric guitars, and strong anthemic rhythms with high power output.',
      bestFor: 'Weight Lifting, Intense Coding, Road Trips'
    };
  }

  if (danceability > 0.68) {
    if (valence > 0.6) {
      return {
        name: 'Feel-Good Grooves',
        emoji: '☀️',
        description: 'Upbeat, highly danceable tracks bursting with positive energy and cheerful melodies to lift your mood.',
        bestFor: 'Bright Mornings, Cookouts, Happy Hours'
      };
    }
    return {
      name: 'Late-Night Late Beats',
      emoji: '🌙',
      description: 'Sleek, bass-heavy grooves with a slightly darker, mysterious edge. Heavy rhythmic focus.',
      bestFor: 'Night Drives, Lounge Chill, Pre-Parties'
    };
  }

  // Default backup profiles based on index
  const backups = [
    { name: 'Harmonic Lounge', emoji: '🍸', description: 'Balanced pop, indie, and chill R&B tracks featuring moderate tempos and rich musicality.', bestFor: 'Lounge Work, Dinner Parties, Evening Wind-down' },
    { name: 'Vibrant Sync', emoji: '⚡', description: 'Faster-paced tracks combining alternative, pop, and modern electronic flavors.', bestFor: 'Multitasking, Commuting, Active Focus' },
    { name: 'Melodic Reverie', emoji: '💭', description: 'Reflective, atmospheric tunes with beautiful synth lines and emotional depth.', bestFor: 'Late Night Coding, Creative Writing, Solitude' },
    { name: 'Rhythm Horizon', emoji: '🎧', description: 'Bass-guided modern productions featuring a seamless blend of synthwave and pop textures.', bestFor: 'Driving, Focus Flow, Casual Listening' }
  ];

  return backups[index % backups.length];
}
