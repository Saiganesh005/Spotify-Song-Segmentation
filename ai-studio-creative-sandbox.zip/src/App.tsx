import { useState, useEffect, useRef } from 'react';
import { 
  Music, 
  Sliders, 
  Layers, 
  Sparkles, 
  Play, 
  Pause, 
  Compass, 
  Activity, 
  TrendingUp, 
  RefreshCw, 
  ListMusic, 
  Info,
  Check,
  Disc,
  ArrowRight,
  Heart,
  Volume2,
  ChevronRight,
  Database,
  BarChart3,
  LayoutGrid,
  SlidersHorizontal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SPOTIFY_TRACKS, AUDIO_FEATURES, Track } from './data/tracks';
import { runKMeans, Cluster, getFeatureValue } from './utils/clustering';

const spotifyBg = new URL('./assets/images/spotify_bg_1784640136091.jpg', import.meta.url).href;

const HUMAN_EMOTIONS = [
  { id: 'happy', label: '😊 Happy & Joyful', description: 'Upbeat, cheerful pop rhythms that elevate your mood' },
  { id: 'melancholic', label: '😢 Melancholic & Sad', description: 'Deep, reflective acoustic and slow piano melodies' },
  { id: 'calm', label: '🧘 Calm & Peaceful', description: 'Ambient classical and serene organic soundscapes' },
  { id: 'pumped', label: '⚡ Pumped & Energetic', description: 'Intense hip-hop and electronic anthems for training' },
  { id: 'focus', label: '🧠 Focus & Thoughtful', description: 'Cozy, low-key acoustic focus and soft rhythms' },
  { id: 'romantic', label: '💖 Romantic & Passionate', description: 'Smooth, soulful R&B and warm acoustic ballads' },
  { id: 'dreamy', label: '🌌 Dreamy & Trippy', description: 'Spacey electronic synth textures and cinematic beats' },
  { id: 'frustrated', label: '🔥 Intense & Rebellious', description: 'Heavy, high-energy rock and fast-tempo beats' }
];

export default function App() {
  // Clustering Configuration state
  const [k, setK] = useState<number>(4);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    'danceability', 'energy', 'acousticness'
  ]);
  const [clusters, setClusters] = useState<Cluster[]>([]);
  const [selectedClusterId, setSelectedClusterId] = useState<number | null>(0);
  
  // Scatter Plot Axes Selection
  const [xAxisFeature, setXAxisFeature] = useState<string>('energy');
  const [yAxisFeature, setYAxisFeature] = useState<string>('danceability');

  // Analytics Dashboard & Dataset state
  const [activeExplorerTab, setActiveExplorerTab] = useState<'plots' | 'dataset'>('plots');
  const [activePlotsSubTab, setActivePlotsSubTab] = useState<'count' | 'scatter' | 'box' | 'pairplot' | 'heatmap' | 'averages'>('count');
  const [boxPlotFeature, setBoxPlotFeature] = useState<string>('danceability');
  const [datasetSearch, setDatasetSearch] = useState<string>('');
  const [datasetClusterFilter, setDatasetClusterFilter] = useState<string>('all');
  const [hoveredCorrelation, setHoveredCorrelation] = useState<{f1: string; f2: string; val: number} | null>(null);
  const [hoveredPairCell, setHoveredPairCell] = useState<{x: string; y: string} | null>(null);
  const [selectedMatrixCell, setSelectedMatrixCell] = useState<{ clusterId: number; genre: string } | null>(null);

  // Pearson correlation calculation helper
  const calculateCorrelation = (feat1: string, feat2: string): number => {
    const n = SPOTIFY_TRACKS.length;
    if (n === 0) return 0;

    const x = SPOTIFY_TRACKS.map(t => getFeatureValue(t, feat1));
    const y = SPOTIFY_TRACKS.map(t => getFeatureValue(t, feat2));

    const meanX = x.reduce((a, b) => a + b, 0) / n;
    const meanY = y.reduce((a, b) => a + b, 0) / n;

    const num = x.reduce((sum, val, i) => sum + (val - meanX) * (y[i] - meanY), 0);
    const denX = Math.sqrt(x.reduce((sum, val) => sum + Math.pow(val - meanX, 2), 0));
    const denY = Math.sqrt(y.reduce((sum, val) => sum + Math.pow(val - meanY, 2), 0));

    if (denX * denY === 0) return 0;
    return num / (denX * denY);
  };
  
  // Search / Selection state
  const [activeTrack, setActiveTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playerProgress, setPlayerProgress] = useState<number>(30);
  
  // AI Enrichment / Loading states
  const [isEnriching, setIsEnriching] = useState<boolean>(false);
  const [enrichmentError, setEnrichmentError] = useState<string>('');
  
  // Vibe Matcher states
  const [vibePrompt, setVibePrompt] = useState<string>('');
  const [isMatching, setIsMatching] = useState<boolean>(false);
  const [matchedClusterId, setMatchedClusterId] = useState<number | null>(null);
  const [vibeMatchExplanation, setVibeMatchExplanation] = useState<string>('');

  // Manual Predictor States
  const [predDanceability, setPredDanceability] = useState<number>(0.5);
  const [predEnergy, setPredEnergy] = useState<number>(0.5);
  const [predValence, setPredValence] = useState<number>(0.5);
  const [predAcousticness, setPredAcousticness] = useState<number>(0.5);
  const [predTempo, setPredTempo] = useState<number>(120);
  const [isPredicting, setIsPredicting] = useState<boolean>(false);
  const [predictionSuccessMessage, setPredictionSuccessMessage] = useState<string>('');

  const [predictedClusterInfo, setPredictedClusterInfo] = useState<{
    cluster: Cluster | null;
    distances: { clusterId: number; distance: number }[];
  }>({ cluster: null, distances: [] });

  // Regression / Clustering Distance Metrics
  const calculateClusteringMetrics = () => {
    if (clusters.length === 0) return { wcss: 0, mse: 0, rmse: 0, mae: 0, r2: 0 };

    let totalWCSS = 0;
    let totalMAE = 0;
    let totalPointsCount = 0;

    const globalMeans: { [feat: string]: number } = {};
    selectedFeatures.forEach((feat) => {
      let sum = 0;
      SPOTIFY_TRACKS.forEach((track) => {
        let val = getFeatureValue(track, feat);
        if (feat === 'tempo') {
          val = Math.max(0, Math.min(1, (val - 60) / 120));
        }
        sum += val;
      });
      globalMeans[feat] = sum / SPOTIFY_TRACKS.length;
    });

    let totalTSS = 0;
    SPOTIFY_TRACKS.forEach((track) => {
      selectedFeatures.forEach((feat) => {
        let val = getFeatureValue(track, feat);
        if (feat === 'tempo') {
          val = Math.max(0, Math.min(1, (val - 60) / 120));
        }
        const diff = val - globalMeans[feat];
        totalTSS += diff * diff;
      });
    });

    clusters.forEach((cluster) => {
      cluster.tracks.forEach((track) => {
        let trackDistSquared = 0;
        let trackDistAbs = 0;
        selectedFeatures.forEach((feat) => {
          let val = getFeatureValue(track, feat);
          if (feat === 'tempo') {
            val = Math.max(0, Math.min(1, (val - 60) / 120));
          }
          let centroidVal = cluster.centroid[feat] || 0;
          if (feat === 'tempo') {
            centroidVal = Math.max(0, Math.min(1, (centroidVal - 60) / 120));
          }
          const diff = val - centroidVal;
          trackDistSquared += diff * diff;
          trackDistAbs += Math.abs(diff);
        });
        totalWCSS += trackDistSquared;
        totalMAE += Math.sqrt(trackDistSquared);
        totalPointsCount++;
      });
    });

    const mse = totalPointsCount > 0 ? totalWCSS / totalPointsCount : 0;
    const rmse = Math.sqrt(mse);
    const mae = totalPointsCount > 0 ? totalMAE / totalPointsCount : 0;
    const r2 = totalTSS > 0 ? 1 - (totalWCSS / totalTSS) : 0;

    return {
      wcss: totalWCSS,
      mse,
      rmse,
      mae,
      r2
    };
  };

  // Performance Metric: Live Silhouette Score
  const calculateSilhouetteScore = (): number => {
    if (clusters.length < 2) return 0;
    
    let totalSilhouette = 0;
    let validPoints = 0;

    const getTrackDistance = (t1: Track, t2: Track) => {
      let sum = 0;
      selectedFeatures.forEach((feat) => {
        let v1 = getFeatureValue(t1, feat);
        let v2 = getFeatureValue(t2, feat);
        if (feat === 'tempo') {
          v1 = Math.max(0, Math.min(1, (v1 - 60) / 120));
          v2 = Math.max(0, Math.min(1, (v2 - 60) / 120));
        }
        sum += Math.pow(v1 - v2, 2);
      });
      return Math.sqrt(sum);
    };

    SPOTIFY_TRACKS.forEach((track) => {
      const ownCluster = clusters.find((c) => c.tracks.some((t) => t.id === track.id));
      if (!ownCluster || ownCluster.tracks.length <= 1) return;

      let sumA = 0;
      ownCluster.tracks.forEach((otherTrack) => {
        if (otherTrack.id !== track.id) {
          sumA += getTrackDistance(track, otherTrack);
        }
      });
      const a = sumA / (ownCluster.tracks.length - 1);

      let minB = Infinity;
      clusters.forEach((otherCluster) => {
        if (otherCluster.id === ownCluster.id || otherCluster.tracks.length === 0) return;

        let sumB = 0;
        otherCluster.tracks.forEach((otherTrack) => {
          sumB += getTrackDistance(track, otherTrack);
        });
        const meanB = sumB / otherCluster.tracks.length;
        if (meanB < minB) {
          minB = meanB;
        }
      });

      const b = minB;
      if (Math.max(a, b) > 0) {
        const s = (b - a) / Math.max(a, b);
        totalSilhouette += s;
        validPoints++;
      }
    });

    return validPoints > 0 ? totalSilhouette / validPoints : 0;
  };

  // Performance Metric: Davies-Bouldin Index
  const calculateDaviesBouldinIndex = (): number => {
    if (clusters.length < 2) return 0;

    const scatters = clusters.map((cluster) => {
      if (cluster.tracks.length === 0) return 0;
      let sumDist = 0;
      cluster.tracks.forEach((track) => {
        let sumOfSquares = 0;
        selectedFeatures.forEach((feat) => {
          let val = getFeatureValue(track, feat);
          if (feat === 'tempo') {
            val = Math.max(0, Math.min(1, (val - 60) / 120));
          }
          let centroidVal = cluster.centroid[feat] || 0;
          if (feat === 'tempo') {
            centroidVal = Math.max(0, Math.min(1, (centroidVal - 60) / 120));
          }
          sumOfSquares += Math.pow(val - centroidVal, 2);
        });
        sumDist += Math.sqrt(sumOfSquares);
      });
      return sumDist / cluster.tracks.length;
    });

    const getCentroidDistance = (c1: Cluster, c2: Cluster) => {
      let sum = 0;
      selectedFeatures.forEach((feat) => {
        let v1 = c1.centroid[feat] || 0;
        let v2 = c2.centroid[feat] || 0;
        if (feat === 'tempo') {
          v1 = Math.max(0, Math.min(1, (v1 - 60) / 120));
          v2 = Math.max(0, Math.min(1, (v2 - 60) / 120));
        }
        sum += Math.pow(v1 - v2, 2);
      });
      return Math.sqrt(sum);
    };

    let dbSum = 0;
    let activeClustersCount = 0;

    for (let i = 0; i < clusters.length; i++) {
      if (clusters[i].tracks.length === 0) continue;
      activeClustersCount++;
      let maxRatio = 0;

      for (let j = 0; j < clusters.length; j++) {
        if (i === j || clusters[j].tracks.length === 0) continue;

        const d = getCentroidDistance(clusters[i], clusters[j]);
        if (d > 0) {
          const ratio = (scatters[i] + scatters[j]) / d;
          if (ratio > maxRatio) {
            maxRatio = ratio;
          }
        }
      }
      dbSum += maxRatio;
    }

    return activeClustersCount > 0 ? dbSum / activeClustersCount : 0;
  };

  // Predict function
  const getPredictedClusterId = (
    dance: number,
    energy: number,
    valence: number,
    acoustic: number,
    tempo: number,
    activeClusters: Cluster[],
    activeFeatures: string[]
  ) => {
    if (activeClusters.length === 0) return null;

    const getManualFeatureValue = (feat: string): number => {
      if (feat === 'danceability') return dance;
      if (feat === 'energy') return energy;
      if (feat === 'valence') return valence;
      if (feat === 'acousticness') return acoustic;
      if (feat === 'tempo') {
        return Math.max(0, Math.min(1, (tempo - 60) / 120));
      }
      return 0;
    };

    let closestId = 0;
    let minDistance = Infinity;
    const distances: { clusterId: number; distance: number }[] = [];

    activeClusters.forEach((cluster) => {
      let sumOfSquares = 0;
      activeFeatures.forEach((feat) => {
        const manualVal = getManualFeatureValue(feat);
        let centroidVal = cluster.centroid[feat] || 0;
        if (feat === 'tempo') {
          centroidVal = Math.max(0, Math.min(1, (centroidVal - 60) / 120));
        }
        sumOfSquares += Math.pow(manualVal - centroidVal, 2);
      });

      const dist = Math.sqrt(sumOfSquares);
      distances.push({ clusterId: cluster.id, distance: dist });

      if (dist < minDistance) {
        minDistance = dist;
        closestId = cluster.id;
      }
    });

    return { closestId, distances };
  };

  const executePrediction = (isManual: boolean = false) => {
    if (clusters.length === 0) return;
    const result = getPredictedClusterId(
      predDanceability,
      predEnergy,
      predValence,
      predAcousticness,
      predTempo,
      clusters,
      selectedFeatures
    );
    if (result) {
      const match = clusters.find(c => c.id === result.closestId) || null;
      setPredictedClusterInfo({
        cluster: match,
        distances: result.distances
      });
      if (isManual) {
        setPredictionSuccessMessage('Cluster profile predicted successfully!');
      }
    }
  };

  const handleManualPredict = () => {
    setIsPredicting(true);
    setPredictionSuccessMessage('');
    setTimeout(() => {
      executePrediction(true);
      setIsPredicting(false);
    }, 450);
  };

  useEffect(() => {
    executePrediction(false);
  }, [clusters, selectedFeatures, predDanceability, predEnergy, predValence, predAcousticness, predTempo]);

  // Run initial clustering when component mounts or config changes
  useEffect(() => {
    recalculateClusters();
  }, [k, selectedFeatures]);

  // Handle music player progress bar mock timer
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setPlayerProgress((prev) => (prev >= 100 ? 0 : prev + 1));
      }, 800);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const recalculateClusters = () => {
    const freshClusters = runKMeans(SPOTIFY_TRACKS, k, selectedFeatures);
    setClusters(freshClusters);
    // Auto-select first cluster or preserve selection within bounds
    if (selectedClusterId === null || selectedClusterId >= freshClusters.length) {
      setSelectedClusterId(0);
    }
  };

  const handleFeatureToggle = (featureId: string) => {
    if (selectedFeatures.includes(featureId)) {
      if (selectedFeatures.length > 1) {
        setSelectedFeatures(selectedFeatures.filter(f => f !== featureId));
      }
    } else {
      setSelectedFeatures([...selectedFeatures, featureId]);
    }
  };

  // AI-driven Cluster Enrichment using Gemini
  const handleAIEnrichClusters = async () => {
    if (isEnriching) return;
    setIsEnriching(true);
    setEnrichmentError('');

    try {
      // Build a detailed snapshot of our calculated clusters
      const clustersSummary = clusters.map(c => ({
        id: c.id,
        trackCount: c.tracks.length,
        topSongs: c.tracks.slice(0, 4).map(t => `${t.title} by ${t.artist}`),
        averages: {
          danceability: c.centroid.danceability.toFixed(2),
          energy: c.centroid.energy.toFixed(2),
          valence: c.centroid.valence.toFixed(2),
          acousticness: c.centroid.acousticness.toFixed(2),
          tempo: Math.round(c.centroid.tempo)
        }
      }));

      const systemInstruction = `You are a musicologist, Spotify algorithm engineer, and creative curator.
Analyze the provided cluster data (track lists, averages) and generate a witty, highly customized profile for each cluster group.
Format your response strictly as a valid JSON array matching this shape:
[
  {
    "id": number,
    "name": "Creative name of the music segment (e.g. Electric Late Nights, Acoustic Coffeehouse)",
    "emoji": "Single emoji fitting the vibe",
    "description": "Engaging 1-2 sentence description detailing who this segment fits and the sonic landscape.",
    "bestFor": "Comma separated list of 2-3 target moods/activities"
  }
]
Do not return any extra markdown formatting or preamble outside of the pure JSON array, so it can be parsed cleanly.`;

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: `Here are the currently calculated music clusters: \n${JSON.stringify(clustersSummary, null, 2)}` }]
            }
          ],
          systemInstruction
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to get creative cluster profiling.');
      }

      // Safely parse JSON array returned by Gemini
      let cleanedText = data.text.trim();
      // Handle potential markdown backticks in the response
      if (cleanedText.startsWith('```json')) {
        cleanedText = cleanedText.substring(7);
      }
      if (cleanedText.endsWith('```')) {
        cleanedText = cleanedText.substring(0, cleanedText.length - 3);
      }
      cleanedText = cleanedText.trim();

      const enrichedProfiles = JSON.parse(cleanedText);
      if (Array.isArray(enrichedProfiles)) {
        setClusters(prev => prev.map(cluster => {
          const match = enrichedProfiles.find((p: any) => p.id === cluster.id);
          if (match) {
            return {
              ...cluster,
              name: match.name || cluster.name,
              emoji: match.emoji || cluster.emoji,
              description: match.description || cluster.description,
              bestFor: match.bestFor || cluster.bestFor
            };
          }
          return cluster;
        }));
      } else {
        throw new Error("Did not receive a structured array.");
      }
    } catch (err: any) {
      console.error(err);
      setEnrichmentError(err.message || 'Error executing AI enrichment. Using intelligent defaults instead.');
    } finally {
      setIsEnriching(false);
    }
  };

  // dynamic Vector Vibe Matcher
  const handleVibeMatch = async (presetText?: string) => {
    const textToAnalyze = presetText || vibePrompt;
    if (!textToAnalyze.trim() || isMatching) return;

    setIsMatching(true);
    setVibeMatchExplanation('');

    try {
      // Use Gemini to convert natural language vibe to targeted audio feature coordinates
      const systemInstruction = `You are an expert Spotify Playlist DJ and audio feature analyzer.
Analyze the user's current mood, activity, or vibe description. Extract their implied musical preferences on a scale from 0 to 1 for: danceability, energy, acousticness, and valence.
Output your analysis as a valid, pure JSON object containing a brief 2-sentence explanation of why you selected these values and the targets themselves:
{
  "explanation": "Why these feature values fit their description...",
  "targets": {
    "danceability": number,
    "energy": number,
    "acousticness": number,
    "valence": number
  }
}
Do not include any other text, preambles, or markdown wrapper format.`;

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: `I want to find music that fits this vibe: "${textToAnalyze}"` }]
            }
          ],
          systemInstruction
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to match mood.');
      }

      let cleanedText = data.text.trim();
      if (cleanedText.startsWith('```json')) {
        cleanedText = cleanedText.substring(7);
      }
      if (cleanedText.endsWith('```')) {
        cleanedText = cleanedText.substring(0, cleanedText.length - 3);
      }
      cleanedText = cleanedText.trim();

      const parsedMatch = JSON.parse(cleanedText);
      const targets = parsedMatch.targets;

      // Find the best cluster group by measuring Euclidean distance to each cluster centroid
      let closestClusterId = 0;
      let minDistance = Infinity;

      clusters.forEach(cluster => {
        const d_dance = targets.danceability - cluster.centroid.danceability;
        const d_energy = targets.energy - cluster.centroid.energy;
        const d_acoustic = targets.acousticness - cluster.centroid.acousticness;
        const d_val = targets.valence - cluster.centroid.valence;

        const distance = Math.sqrt(
          Math.pow(d_dance, 2) + 
          Math.pow(d_energy, 2) + 
          Math.pow(d_acoustic, 2) + 
          Math.pow(d_val, 2)
        );

        if (distance < minDistance) {
          minDistance = distance;
          closestClusterId = cluster.id;
        }
      });

      setMatchedClusterId(closestClusterId);
      setSelectedClusterId(closestClusterId);
      setVibeMatchExplanation(parsedMatch.explanation);
      if (!presetText) setVibePrompt('');
    } catch (err: any) {
      console.error(err);
      // Fallback matching logic on client-side rules if API fails/offline
      let bestClusterIdx = 0;
      if (textToAnalyze.toLowerCase().includes('sleep') || textToAnalyze.toLowerCase().includes('study') || textToAnalyze.toLowerCase().includes('quiet')) {
        // Find cluster with highest acousticness
        let maxAcoustic = -1;
        clusters.forEach((c, idx) => {
          if (c.centroid.acousticness > maxAcoustic) {
            maxAcoustic = c.centroid.acousticness;
            bestClusterIdx = idx;
          }
        });
      } else {
        // Find cluster with highest energy
        let maxEnergy = -1;
        clusters.forEach((c, idx) => {
          if (c.centroid.energy > maxEnergy) {
            maxEnergy = c.centroid.energy;
            bestClusterIdx = idx;
          }
        });
      }
      setMatchedClusterId(bestClusterIdx);
      setSelectedClusterId(bestClusterIdx);
      setVibeMatchExplanation(`Client-side local fallback completed. We mapped your vibe to Cluster group ${bestClusterIdx + 1} which exhibits the closest average audio characteristics.`);
    } finally {
      setIsMatching(false);
    }
  };

  const handleTrackPlayToggle = (track: Track) => {
    if (activeTrack?.id === track.id) {
      setIsPlaying(!isPlaying);
    } else {
      setActiveTrack(track);
      setIsPlaying(true);
      setPlayerProgress(0);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-emerald-500/30 selection:text-emerald-300 relative overflow-x-hidden">
      
      {/* Blurred Background Image Backdrop */}
      <div 
        className="fixed inset-0 z-0 pointer-events-none select-none"
        style={{
          backgroundImage: `url(${spotifyBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          opacity: 0.15,
          filter: 'blur(30px) brightness(0.7)',
          transform: 'scale(1.1)', // eliminates any blur boundary bleeding
        }}
      />

      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top Header Banner */}
        <header className="border-b border-slate-900 bg-slate-950/70 backdrop-blur-md sticky top-0 z-40 px-4 py-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500 text-slate-950 rounded-xl shadow-lg shadow-emerald-500/20">
              <Disc size={24} className="animate-spin" style={{ animationDuration: '3s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-emerald-400 to-teal-200 bg-clip-text text-transparent">
                  Spotify Genre Segmentation
                </h1>
                <span className="text-[10px] uppercase font-bold tracking-widest bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  K-Means Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Dynamic track clustering on raw audio features with high-dimensional vector alignment & AI-powered segment profiling.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Quick Metrics */}
            <div className="flex items-center gap-1 bg-slate-900/60 border border-slate-800/80 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-300">
              <Database size={13} className="text-emerald-400" />
              <span>Pool: <strong>{SPOTIFY_TRACKS.length} Tracks</strong></span>
            </div>
            <div className="flex items-center gap-1 bg-slate-900/60 border border-slate-800/80 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-300">
              <Sliders size={13} className="text-emerald-400" />
              <span>K: <strong>{k} Clusters</strong></span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col lg:grid lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Controls & Setup (4 cols) */}
        <section className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Card 1: Segmentation Engine */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-5">
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
              <div className="flex items-center gap-2">
                <Sliders size={18} className="text-emerald-400" />
                <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Segment Engine</h2>
              </div>
              <button 
                onClick={recalculateClusters}
                className="p-1 rounded-md hover:bg-slate-800 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                title="Force Re-cluster"
              >
                <RefreshCw size={14} />
              </button>
            </div>

            {/* Slider to adjust K */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">Target Segments (K)</span>
                <span className="font-mono text-emerald-400 font-bold bg-emerald-400/10 px-2 py-0.5 rounded-md border border-emerald-500/10">{k} Groups</span>
              </div>
              <input 
                type="range" 
                min={2} 
                max={6} 
                value={k}
                onChange={(e) => setK(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <p className="text-[10px] text-slate-500">
                Number of centroids to position inside the multi-dimensional audio feature landscape.
              </p>
            </div>

            {/* Features Selection checkboxes */}
            <div className="space-y-3">
              <span className="text-xs text-slate-400 font-medium block">Active Feature Space</span>
              <div className="space-y-2.5">
                {AUDIO_FEATURES.map((feature) => {
                  const isActive = selectedFeatures.includes(feature.id);
                  return (
                    <button
                      key={feature.id}
                      onClick={() => handleFeatureToggle(feature.id)}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-start gap-3 cursor-pointer ${
                        isActive 
                          ? 'bg-emerald-500/5 border-emerald-500/30 shadow-md shadow-emerald-500/5' 
                          : 'bg-slate-950/40 border-slate-800/60 hover:border-slate-700 hover:bg-slate-900/40'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded mt-0.5 shrink-0 flex items-center justify-center border transition-all ${
                        isActive 
                          ? 'bg-emerald-500 border-emerald-500 text-slate-950' 
                          : 'border-slate-700 bg-slate-950'
                      }`}>
                        {isActive && <Check size={12} className="stroke-[3]" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs font-semibold ${isActive ? 'text-emerald-400' : 'text-slate-300'}`}>
                            {feature.name}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-0.5 block leading-relaxed">
                          {feature.desc}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          {/* Card 3: Manual Segment Predictor */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-5">
            <div className="flex items-center gap-2 border-b border-slate-800/60 pb-3">
              <Layers size={18} className="text-emerald-400" />
              <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Interactive Predictor</h2>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed">
              Enter custom track values in the boxes below to instantly predict which cluster group the audio profile aligns with.
            </p>

            <div className="grid grid-cols-2 gap-3.5">
              {/* Input: Danceability */}
              <div className="space-y-1.5 col-span-1">
                <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-300">
                  <span>Danceability</span>
                  {selectedFeatures.includes('danceability') ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Actively influences cluster prediction" />
                  ) : (
                    <span className="text-[9px] text-slate-500">(Inactive)</span>
                  )}
                </label>
                <div className="relative">
                  <input 
                    type="number"
                    min="0"
                    max="1"
                    step="0.01"
                    placeholder="0.00 to 1.00"
                    value={predDanceability}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPredDanceability(isNaN(val) ? 0 : Math.max(0, Math.min(1, val)));
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950/80 font-mono text-emerald-400 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500/40 focus:border-emerald-500/50 transition-all"
                  />
                  <span className="absolute right-3 top-2.5 text-[9px] font-mono text-slate-600">0 - 1</span>
                </div>
              </div>

              {/* Input: Energy */}
              <div className="space-y-1.5 col-span-1">
                <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-300">
                  <span>Energy</span>
                  {selectedFeatures.includes('energy') ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Actively influences cluster prediction" />
                  ) : (
                    <span className="text-[9px] text-slate-500">(Inactive)</span>
                  )}
                </label>
                <div className="relative">
                  <input 
                    type="number"
                    min="0"
                    max="1"
                    step="0.01"
                    placeholder="0.00 to 1.00"
                    value={predEnergy}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPredEnergy(isNaN(val) ? 0 : Math.max(0, Math.min(1, val)));
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950/80 font-mono text-emerald-400 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500/40 focus:border-emerald-500/50 transition-all"
                  />
                  <span className="absolute right-3 top-2.5 text-[9px] font-mono text-slate-600">0 - 1</span>
                </div>
              </div>

              {/* Input: Valence */}
              <div className="space-y-1.5 col-span-1">
                <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-300">
                  <span>Valence</span>
                  {selectedFeatures.includes('valence') ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Actively influences cluster prediction" />
                  ) : (
                    <span className="text-[9px] text-slate-500">(Inactive)</span>
                  )}
                </label>
                <div className="relative">
                  <input 
                    type="number"
                    min="0"
                    max="1"
                    step="0.01"
                    placeholder="0.00 to 1.00"
                    value={predValence}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPredValence(isNaN(val) ? 0 : Math.max(0, Math.min(1, val)));
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950/80 font-mono text-emerald-400 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500/40 focus:border-emerald-500/50 transition-all"
                  />
                  <span className="absolute right-3 top-2.5 text-[9px] font-mono text-slate-600">0 - 1</span>
                </div>
              </div>

              {/* Input: Acousticness */}
              <div className="space-y-1.5 col-span-1">
                <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-300">
                  <span>Acousticness</span>
                  {selectedFeatures.includes('acousticness') ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Actively influences cluster prediction" />
                  ) : (
                    <span className="text-[9px] text-slate-500">(Inactive)</span>
                  )}
                </label>
                <div className="relative">
                  <input 
                    type="number"
                    min="0"
                    max="1"
                    step="0.01"
                    placeholder="0.00 to 1.00"
                    value={predAcousticness}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPredAcousticness(isNaN(val) ? 0 : Math.max(0, Math.min(1, val)));
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950/80 font-mono text-emerald-400 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500/40 focus:border-emerald-500/50 transition-all"
                  />
                  <span className="absolute right-3 top-2.5 text-[9px] font-mono text-slate-600">0 - 1</span>
                </div>
              </div>

              {/* Input: Tempo */}
              <div className="space-y-1.5 col-span-2">
                <label className="flex items-center gap-1.5 text-[11px] font-medium text-slate-300">
                  <span>Tempo (BPM)</span>
                  {selectedFeatures.includes('tempo') ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Actively influences cluster prediction" />
                  ) : (
                    <span className="text-[9px] text-slate-500">(Inactive)</span>
                  )}
                </label>
                <div className="relative">
                  <input 
                    type="number"
                    min="60"
                    max="180"
                    step="1"
                    placeholder="60 to 180"
                    value={predTempo}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setPredTempo(isNaN(val) ? 60 : Math.max(60, Math.min(180, val)));
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-800 bg-slate-950/80 font-mono text-emerald-400 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500/40 focus:border-emerald-500/50 transition-all"
                  />
                  <span className="absolute right-3 top-2.5 text-[9px] font-mono text-slate-600">60 - 180 BPM</span>
                </div>
              </div>
            </div>

            {/* Predict Action Button */}
            <button
              onClick={handleManualPredict}
              disabled={isPredicting}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-bold tracking-wide shadow-lg shadow-emerald-500/10 hover:shadow-emerald-500/20 active:scale-[0.98] transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
            >
              {isPredicting ? (
                <>
                  <RefreshCw size={14} className="animate-spin" />
                  <span>Calculating Distances...</span>
                </>
              ) : (
                <>
                  <Activity size={14} />
                  <span>Predict Cluster Group</span>
                </>
              )}
            </button>

            {/* Success feedback message */}
            {predictionSuccessMessage && (
              <div className="text-[10px] text-emerald-400 font-medium bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl text-center flex items-center justify-center gap-1.5 animate-pulse">
                <Check size={11} />
                <span>{predictionSuccessMessage}</span>
              </div>
            )}

            {/* Prediction Output Display */}
            {predictedClusterInfo.cluster && (
              <div className="bg-slate-950/60 border border-slate-850 p-4 rounded-xl space-y-3 relative overflow-hidden transition-all">
                <div 
                  className="absolute top-0 bottom-0 left-0 w-1" 
                  style={{ backgroundColor: predictedClusterInfo.cluster.color }}
                />
                
                <div className="pl-1.5 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="text-[10px] uppercase font-bold tracking-widest text-slate-500">
                      Prediction Output
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded">
                      Matched Segment
                    </span>
                  </div>
                  
                  {/* Prominent Cluster Number and Cluster Name Display */}
                  <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-900 flex flex-col gap-1">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-400 font-semibold">
                      Cluster Number: #{predictedClusterInfo.cluster.id + 1}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{predictedClusterInfo.cluster.emoji}</span>
                      <h4 className="text-sm font-bold text-slate-100">
                        {predictedClusterInfo.cluster.name}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <span className="text-[10px] text-slate-400 leading-relaxed max-w-[70%]">
                      {predictedClusterInfo.cluster.description}
                    </span>
                    <button
                      onClick={() => {
                        if (predictedClusterInfo.cluster) {
                          setSelectedClusterId(predictedClusterInfo.cluster.id);
                        }
                      }}
                      className="text-[10px] text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-0.5 cursor-pointer transition-colors shrink-0"
                    >
                      <span>Show Playlist</span>
                      <ChevronRight size={12} />
                    </button>
                  </div>

                  {/* Similarity Metrics */}
                  <div className="pt-2 border-t border-slate-850 space-y-2">
                    <div className="text-[9px] uppercase tracking-wider text-slate-500 font-semibold">
                      Relative Distances to Centroids
                    </div>
                    <div className="space-y-1.5">
                      {predictedClusterInfo.distances.map((distObj) => {
                        const targetClust = clusters.find(c => c.id === distObj.clusterId);
                        if (!targetClust) return null;
                        
                        const maxExpectedDist = 1.5;
                        const proximityScore = Math.max(0, Math.min(100, Math.round((1 - (distObj.distance / maxExpectedDist)) * 100)));
                        const isWinner = distObj.clusterId === predictedClusterInfo.cluster?.id;

                        return (
                          <div key={distObj.clusterId} className="flex items-center gap-2 text-[9px] font-mono">
                            <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: targetClust.color }} />
                            <span className={`w-24 truncate ${isWinner ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
                              {targetClust.name}
                            </span>
                            <div className="flex-1 h-1 bg-slate-900 rounded-full overflow-hidden">
                              <div 
                                className="h-full rounded-full transition-all duration-300" 
                                style={{ 
                                  width: `${proximityScore}%`, 
                                  backgroundColor: isWinner ? targetClust.color : '#475569' 
                                }}
                              />
                            </div>
                            <span className="text-slate-500 text-right w-10">
                              {distObj.distance.toFixed(3)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>
              </div>
            )}
          </div>

          {/* Card: Regression Metrics */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-slate-800/60 pb-3">
              <TrendingUp size={18} className="text-emerald-400" />
              <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Regression & Error Metrics</h2>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed">
              Continuous error distances between high-dimensional song vectors and their mapped cluster centroids.
            </p>

            {(() => {
              const metrics = calculateClusteringMetrics();
              return (
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900/60 flex flex-col gap-1">
                    <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono">Inertia (WCSS)</span>
                    <span className="text-xs font-mono font-bold text-emerald-400">{metrics.wcss.toFixed(4)}</span>
                    <span className="text-[8px] text-slate-600">Sum of squared distances</span>
                  </div>
                  
                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900/60 flex flex-col gap-1">
                    <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono">Mean Absolute Error (MAE)</span>
                    <span className="text-xs font-mono font-bold text-emerald-400">{metrics.mae.toFixed(4)}</span>
                    <span className="text-[8px] text-slate-600">Average absolute distance</span>
                  </div>

                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900/60 flex flex-col gap-1">
                    <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono">Mean Squared Error (MSE)</span>
                    <span className="text-xs font-mono font-bold text-emerald-400">{metrics.mse.toFixed(4)}</span>
                    <span className="text-[8px] text-slate-600">Variance of distances</span>
                  </div>

                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-900/60 flex flex-col gap-1">
                    <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono">Explained Variance (R²)</span>
                    <span className="text-xs font-mono font-bold text-teal-400">{(metrics.r2 * 100).toFixed(1)}%</span>
                    <span className="text-[8px] text-slate-600">Dataset variance explained</span>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Card: Performance Metrics */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-slate-800/60 pb-3">
              <Activity size={18} className="text-emerald-400" />
              <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Model Performance</h2>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Objective mathematical scores indicating cluster cohesion, separation quality, and spatial density.
            </p>

            <div className="space-y-3">
              {/* Silhouette Score */}
              {(() => {
                const sScore = calculateSilhouetteScore();
                // Map from [-1, 1] to a percentage progress bar
                const sPercentage = Math.round(((sScore + 1) / 2) * 100);
                
                return (
                  <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-900/60 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-slate-300 font-semibold uppercase tracking-wider">Silhouette Coefficient</span>
                      <span className="text-emerald-400 font-bold">{sScore.toFixed(3)}</span>
                    </div>
                    
                    <div className="h-1.5 bg-slate-950 border border-slate-900 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-400 transition-all duration-500"
                        style={{ width: `${sPercentage}%` }}
                      />
                    </div>
                    
                    <div className="flex justify-between text-[8px] text-slate-500 font-mono">
                      <span>-1.0 (Worst)</span>
                      <span>0.0 (Overlapping)</span>
                      <span>+1.0 (Best)</span>
                    </div>
                  </div>
                );
              })()}

              {/* Davies-Bouldin Index */}
              {(() => {
                const dbIndex = calculateDaviesBouldinIndex();
                return (
                  <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-900/60 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-slate-300 font-mono block">Davies-Bouldin Index</span>
                      <span className="text-[8px] text-slate-500 leading-tight">Clustering separation ratio (Lower = better)</span>
                    </div>
                    <div className="text-right">
                      <span className="text-base font-mono font-bold text-emerald-400 block">{dbIndex.toFixed(3)}</span>
                      <span className="text-[8.5px] font-mono text-slate-500">Separation Score</span>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>

          {/* Card: Confusion Matrix */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-slate-800/60 pb-3">
              <LayoutGrid size={18} className="text-emerald-400" />
              <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Confusion Matrix</h2>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Cross-tabulation comparing algorithm-computed clusters (rows) against human-labeled original genres (columns). Click any cell to inspect intersecting tracks.
            </p>

            {(() => {
              const CONFUSION_GENRES = ['Pop', 'Hip-Hop', 'Rock', 'Electronic', 'Jazz', 'Classical', 'Latin', 'Acoustic'];
              
              // Find max count to scale colors beautifully
              let maxCountInCell = 1;
              clusters.forEach(cluster => {
                CONFUSION_GENRES.forEach(genre => {
                  const count = cluster.tracks.filter(t => t.genre === genre).length;
                  if (count > maxCountInCell) {
                    maxCountInCell = count;
                  }
                });
              });

              return (
                <div className="space-y-4">
                  <div className="overflow-x-auto pb-1 scrollbar-thin">
                    <div className="min-w-[420px] text-[9px] font-mono">
                      {/* Columns Header Row */}
                      <div className="grid grid-cols-9 gap-1 items-center mb-1 text-center font-bold text-slate-500">
                        <div className="text-left text-[8px] uppercase tracking-wider text-slate-600">Cluster</div>
                        {CONFUSION_GENRES.map(genre => (
                          <div key={genre} className="truncate text-center" title={genre}>{genre}</div>
                        ))}
                      </div>

                      {/* Cluster Rows */}
                      <div className="space-y-1">
                        {clusters.map(cluster => {
                          return (
                            <div key={cluster.id} className="grid grid-cols-9 gap-1 items-center">
                              {/* Row Header */}
                              <div 
                                onClick={() => setSelectedClusterId(cluster.id)}
                                className="flex items-center gap-1 cursor-pointer hover:text-emerald-400 transition-colors py-1 min-w-0"
                              >
                                <span className="shrink-0">{cluster.emoji}</span>
                                <span className="font-bold truncate text-slate-300">C{cluster.id + 1}</span>
                              </div>

                              {/* Matrix Cells */}
                              {CONFUSION_GENRES.map(genre => {
                                const matchingTracks = cluster.tracks.filter(t => t.genre === genre);
                                const count = matchingTracks.length;
                                const isSelected = selectedMatrixCell?.clusterId === cluster.id && selectedMatrixCell?.genre === genre;
                                
                                // Color scale based on density
                                let bgStyle = 'bg-slate-950/60 border border-slate-900/40 text-slate-600';
                                if (count > 0) {
                                  bgStyle = `text-emerald-100 font-bold border border-emerald-500/20`;
                                }

                                return (
                                  <button
                                    key={genre}
                                    onClick={() => {
                                      if (count > 0) {
                                        setSelectedMatrixCell(isSelected ? null : { clusterId: cluster.id, genre });
                                      }
                                    }}
                                    disabled={count === 0}
                                    style={count > 0 ? { backgroundColor: `rgba(16, 185, 129, ${0.15 + (count / maxCountInCell) * 0.8})`, color: count / maxCountInCell > 0.45 ? '#022c22' : '#a7f3d0' } : {}}
                                    className={`aspect-square rounded flex flex-col items-center justify-center transition-all ${bgStyle} ${
                                      count > 0 ? 'hover:scale-105 active:scale-95 cursor-pointer hover:border-white/30' : 'opacity-20 cursor-not-allowed'
                                    } ${isSelected ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-950 z-10' : ''}`}
                                    title={`${cluster.name} × ${genre}: ${count} track(s)`}
                                  >
                                    <span className="text-[10px]">{count}</span>
                                  </button>
                                );
                              })}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Selected Cell Tracks Display Panel */}
                  {selectedMatrixCell && (
                    <div className="bg-slate-950/80 border border-slate-800/80 p-3 rounded-xl space-y-2 text-[10px] animate-fade-in">
                      {(() => {
                        const cellCluster = clusters.find(c => c.id === selectedMatrixCell.clusterId);
                        const cellTracks = cellCluster?.tracks.filter(t => t.genre === selectedMatrixCell.genre) || [];
                        
                        return (
                          <>
                            <div className="flex items-center justify-between text-[9px] uppercase font-bold tracking-wider text-slate-400">
                              <span>Tracks in Intersection</span>
                              <button 
                                onClick={() => setSelectedMatrixCell(null)}
                                className="text-slate-600 hover:text-slate-300 font-bold font-mono px-1 rounded"
                              >
                                [Close]
                              </button>
                            </div>
                            <div className="text-slate-200 font-semibold mb-1">
                              {cellCluster?.emoji} {cellCluster?.name} × <span className="text-emerald-400">{selectedMatrixCell.genre}</span> ({cellTracks.length} tracks)
                            </div>
                            <div className="max-h-32 overflow-y-auto space-y-1 divide-y divide-slate-900/60 scrollbar-thin">
                              {cellTracks.map(t => (
                                <div key={t.id} className="pt-1 flex items-center justify-between gap-2">
                                  <span className="font-bold text-slate-300 truncate">{t.title}</span>
                                  <span className="text-[9px] text-slate-500 italic shrink-0">{t.artist}</span>
                                </div>
                              ))}
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Card 4: Mood Segment finder */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-slate-800/60 pb-3">
              <Compass size={18} className="text-emerald-400" />
              <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Mood Segment finder</h2>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Describe your specific atmosphere or vibe in natural language. We'll use Gemini to extract the precise audio weights and segment you to the best cluster.
            </p>

            {/* Human Emotion Dropdown Selector */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-slate-300 block">
                Identify Mood by Human Emotion:
              </label>
              <select
                onChange={(e) => {
                  const val = e.target.value;
                  if (val) {
                    const preset = HUMAN_EMOTIONS.find(e => e.id === val);
                    if (preset) {
                      setVibePrompt(preset.description);
                      handleVibeMatch(preset.description);
                    }
                  }
                }}
                defaultValue=""
                className="w-full px-3.5 py-2 rounded-xl border border-slate-850 bg-slate-950 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 cursor-pointer"
              >
                <option value="" disabled>-- Select a Human Emotion --</option>
                {HUMAN_EMOTIONS.map((emotion) => (
                  <option key={emotion.id} value={emotion.id}>
                    {emotion.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <input 
                type="text"
                value={vibePrompt}
                onChange={(e) => setVibePrompt(e.target.value)}
                disabled={isMatching}
                placeholder="e.g., Rainy study evening with soft piano..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-800 bg-slate-950 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
              <button
                onClick={() => handleVibeMatch()}
                disabled={!vibePrompt.trim() || isMatching}
                className="w-full py-2 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold tracking-wide hover:bg-emerald-400 active:scale-[0.98] transition-all cursor-pointer disabled:opacity-40 flex items-center justify-center gap-1.5"
              >
                {isMatching ? (
                  <>
                    <RefreshCw size={13} className="animate-spin" />
                    <span>Mapping vibe...</span>
                  </>
                ) : (
                  <>
                    <Activity size={13} />
                    <span>Find My Segment</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick preset chips */}
            <div className="flex flex-wrap gap-1.5 pt-1.5">
              <button 
                onClick={() => handleVibeMatch("Intense Gym Training Workout")}
                className="text-[10px] bg-slate-950 border border-slate-800 hover:border-slate-700 hover:text-white px-2.5 py-1 rounded-full cursor-pointer transition-all"
              >
                🏋️‍♂️ Intense Workout
              </button>
              <button 
                onClick={() => handleVibeMatch("Cozy coffeehouse acoustic focus")}
                className="text-[10px] bg-slate-950 border border-slate-800 hover:border-slate-700 hover:text-white px-2.5 py-1 rounded-full cursor-pointer transition-all"
              >
                ☕ Cozy Focus
              </button>
              <button 
                onClick={() => handleVibeMatch("Late night energetic dance floor hits")}
                className="text-[10px] bg-slate-950 border border-slate-800 hover:border-slate-700 hover:text-white px-2.5 py-1 rounded-full cursor-pointer transition-all"
              >
                🔥 Dance Floor
              </button>
            </div>

            {vibeMatchExplanation && (
              <div className="mt-2 p-3 rounded-xl bg-slate-950/60 border border-slate-850 text-[10px] text-emerald-400/90 leading-relaxed font-sans">
                <div className="font-bold uppercase tracking-wider text-[8px] text-emerald-500 mb-1">AI Matching Report:</div>
                {vibeMatchExplanation}
              </div>
            )}
          </div>
        </section>

        {/* CENTER COLUMN: Visualizer & Active Cluster (5 cols) */}
        <section className="lg:col-span-5 flex flex-col gap-6">
          
          {/* Card 2: Analytics & Clustered Dataset */}
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
              <div className="flex items-center gap-2">
                <TrendingUp size={18} className="text-emerald-400" />
                <h2 className="text-sm font-semibold tracking-wide uppercase text-slate-200">Analytics & Dataset</h2>
              </div>
              
              {/* Explorer Tabs */}
              <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800">
                <button
                  onClick={() => setActiveExplorerTab('plots')}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold tracking-wide transition-all cursor-pointer ${
                    activeExplorerTab === 'plots'
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Plots
                </button>
                <button
                  onClick={() => setActiveExplorerTab('dataset')}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold tracking-wide transition-all cursor-pointer ${
                    activeExplorerTab === 'dataset'
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Dataset
                </button>
              </div>
            </div>

            {activeExplorerTab === 'plots' ? (
              <div className="space-y-4">
                {/* Plots Sub-Tabs Slider */}
                <div className="flex gap-1.5 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                  {[
                    { id: 'count', label: 'Counts', icon: BarChart3 },
                    { id: 'scatter', label: 'Scatter', icon: Compass },
                    { id: 'box', label: 'Box Plot', icon: SlidersHorizontal },
                    { id: 'pairplot', label: 'Pairplot', icon: LayoutGrid },
                    { id: 'heatmap', label: 'Correlation', icon: TrendingUp },
                    { id: 'averages', label: 'Centroids', icon: Sliders }
                  ].map((tab) => {
                    const Icon = tab.icon;
                    const isActive = activePlotsSubTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActivePlotsSubTab(tab.id as any)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-medium font-sans border transition-all cursor-pointer whitespace-nowrap ${
                          isActive
                            ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold shadow-lg shadow-emerald-500/10'
                            : 'bg-slate-950 text-slate-400 border-slate-800/80 hover:text-slate-200 hover:bg-slate-900/60'
                        }`}
                      >
                        <Icon size={11} className={isActive ? 'text-slate-950' : 'text-slate-400'} />
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Subtab content 1: Segment Counts (Bar chart) */}
                {activePlotsSubTab === 'count' && (
                  <div className="space-y-3">
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Distribution of song counts across the {k} computed clusters. Select a bar to highlight that cluster's playlist.
                    </p>
                    
                    <div className="space-y-2.5 bg-slate-950/40 p-3 rounded-xl border border-slate-900">
                      {clusters.map((cluster) => {
                        const count = cluster.tracks.length;
                        const total = SPOTIFY_TRACKS.length;
                        const percent = total > 0 ? (count / total) * 100 : 0;
                        const isSelected = selectedClusterId === cluster.id;
                        
                        return (
                          <div 
                            key={cluster.id} 
                            onClick={() => setSelectedClusterId(cluster.id)}
                            className={`space-y-1 group cursor-pointer p-1.5 rounded-lg transition-all ${
                              isSelected ? 'bg-slate-900/50' : 'hover:bg-slate-900/20'
                            }`}
                          >
                            <div className="flex justify-between items-center text-[10px]">
                              <div className="flex items-center gap-1.5">
                                <span className="text-sm shrink-0">{cluster.emoji}</span>
                                <span className={`font-semibold ${isSelected ? 'text-emerald-400' : 'text-slate-300'}`}>
                                  {cluster.name}
                                </span>
                              </div>
                              <div className="font-mono text-[10px] text-slate-400">
                                <span className="font-bold text-slate-200">{count}</span>
                                <span className="text-slate-600"> / {total}</span>
                                <span className="text-emerald-400 font-semibold ml-2">({percent.toFixed(0)}%)</span>
                              </div>
                            </div>
                            
                            <div className="h-2 bg-slate-950 border border-slate-900 rounded-full overflow-hidden">
                              <div 
                                className="h-full rounded-full transition-all duration-500 ease-out"
                                style={{ 
                                  width: `${percent}%`,
                                  backgroundColor: cluster.color 
                                }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Subtab content 2: Mini Scatter Space */}
                {activePlotsSubTab === 'scatter' && (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <p className="text-[10px] text-slate-400 leading-normal">
                        Interactive space mapping tracks along chosen dimensions:
                      </p>
                      
                      {/* Axis Selectors */}
                      <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800 shrink-0">
                        <select 
                          value={xAxisFeature}
                          onChange={(e) => setXAxisFeature(e.target.value)}
                          className="bg-transparent text-[9.5px] font-medium text-slate-300 focus:outline-none cursor-pointer"
                        >
                          {AUDIO_FEATURES.map(f => (
                            <option key={f.id} value={f.id} className="bg-slate-950 text-slate-300">{f.name} (X)</option>
                          ))}
                        </select>
                        <span className="text-slate-600 text-xs">/</span>
                        <select 
                          value={yAxisFeature}
                          onChange={(e) => setYAxisFeature(e.target.value)}
                          className="bg-transparent text-[9.5px] font-medium text-slate-300 focus:outline-none cursor-pointer"
                        >
                          {AUDIO_FEATURES.map(f => (
                            <option key={f.id} value={f.id} className="bg-slate-950 text-slate-300">{f.name} (Y)</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    
                    <div className="relative bg-slate-950/60 p-2 border border-slate-900 rounded-xl flex flex-col items-center justify-center">
                      <svg className="w-full h-[280px] p-2" viewBox="0 0 300 280">
                        {/* Grid lines */}
                        <line x1="20" y1="260" x2="280" y2="260" stroke="#1e293b" strokeWidth="1" strokeDasharray="2 2" />
                        <line x1="20" y1="20" x2="20" y2="260" stroke="#1e293b" strokeWidth="1" strokeDasharray="2 2" />
                        
                        {/* Render all points */}
                        {SPOTIFY_TRACKS.map((track) => {
                          const xVal = getFeatureValue(track, xAxisFeature);
                          const yVal = getFeatureValue(track, yAxisFeature);
                          
                          // Map to coordinates inside [20, 280] wide and [20, 260] high
                          const cx = 20 + xVal * 260;
                          const cy = 260 - yVal * 240;
                          
                          const trackCluster = clusters.find(c => c.tracks.some(t => t.id === track.id));
                          const isTrackActive = activeTrack?.id === track.id;
                          const nodeColor = trackCluster ? trackCluster.color : '#64748b';
                          
                          return (
                            <circle
                              key={track.id}
                              cx={cx}
                              cy={cy}
                              r={isTrackActive ? 6.5 : 4}
                              fill={nodeColor}
                              className={`transition-all duration-200 cursor-pointer hover:r-6 ${
                                isTrackActive ? 'stroke-white stroke-1.5' : ''
                              }`}
                              onClick={() => handleTrackPlayToggle(track)}
                            >
                              <title>{`${track.title} - ${track.artist}\n${xAxisFeature}: ${xVal.toFixed(2)}, ${yAxisFeature}: ${yVal.toFixed(2)}`}</title>
                            </circle>
                          );
                        })}
                      </svg>
                      
                      {/* X & Y Axis Labels */}
                      <div className="absolute top-2.5 left-4 text-[7.5px] font-mono text-slate-500 uppercase tracking-wider">
                        Y: {yAxisFeature}
                      </div>
                      <div className="absolute bottom-2.5 right-4 text-[7.5px] font-mono text-slate-500 uppercase tracking-wider">
                        X: {xAxisFeature}
                      </div>
                    </div>
                  </div>
                )}

                {/* Subtab content 3: Box Plots */}
                {activePlotsSubTab === 'box' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-[10px] text-slate-400 leading-normal flex-1">
                        Comparative statistical quartile ranges (Min, Q1, Median, Q3, Max) across clusters.
                      </p>
                      
                      <select
                        value={boxPlotFeature}
                        onChange={(e) => setBoxPlotFeature(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[9px] font-mono text-emerald-400 focus:outline-none cursor-pointer shrink-0"
                      >
                        {AUDIO_FEATURES.map(f => (
                          <option key={f.id} value={f.id} className="bg-slate-950">{f.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-900 space-y-4">
                      {clusters.map((cluster) => {
                        // Gather stats
                        const vals = cluster.tracks.map(t => getFeatureValue(t, boxPlotFeature)).sort((a,b)=>a-b);
                        const hasTracks = vals.length > 0;
                        const min = hasTracks ? vals[0] : 0;
                        const q1 = hasTracks ? vals[Math.floor(vals.length * 0.25)] : 0;
                        const median = hasTracks ? vals[Math.floor(vals.length * 0.5)] : 0;
                        const q3 = hasTracks ? vals[Math.floor(vals.length * 0.75)] : 0;
                        const max = hasTracks ? vals[vals.length - 1] : 0;

                        // Width of SVG box is 200px. Offset by 15px. Total width 230px.
                        const scale = (val: number) => 15 + val * 190;
                        
                        return (
                          <div key={cluster.id} className="space-y-1">
                            {/* Header row */}
                            <div className="flex justify-between items-center text-[9px] font-mono">
                              <span className="text-slate-300 font-bold flex items-center gap-1">
                                <span>{cluster.emoji}</span>
                                <span>{cluster.name}</span>
                              </span>
                              <span className="text-emerald-400 font-semibold text-[8px]">
                                Med: {boxPlotFeature === 'tempo' ? `${Math.round(60 + median * 120)} BPM` : median.toFixed(2)}
                              </span>
                            </div>

                            {/* Horizontal Box SVG */}
                            <div className="relative">
                              <svg className="w-full h-[18px]" viewBox="0 0 220 18">
                                {/* Whisker horizontal line */}
                                <line 
                                  x1={scale(min)} 
                                  y1="9" 
                                  x2={scale(max)} 
                                  y2="9" 
                                  stroke="#475569" 
                                  strokeWidth="1" 
                                />
                                
                                {/* Min whisker tick */}
                                <line 
                                  x1={scale(min)} 
                                  y1="5" 
                                  x2={scale(min)} 
                                  y2="13" 
                                  stroke="#475569" 
                                  strokeWidth="1.5" 
                                />

                                {/* Max whisker tick */}
                                <line 
                                  x1={scale(max)} 
                                  y1="5" 
                                  x2={scale(max)} 
                                  y2="13" 
                                  stroke="#475569" 
                                  strokeWidth="1.5" 
                                />

                                {/* Q1 to Q3 Box */}
                                <rect 
                                  x={scale(q1)} 
                                  y="4" 
                                  width={Math.max(2, scale(q3) - scale(q1))} 
                                  height="10" 
                                  fill={`${cluster.color}25`} 
                                  stroke={cluster.color} 
                                  strokeWidth="1"
                                  rx="1"
                                />

                                {/* Median line */}
                                <line 
                                  x1={scale(median)} 
                                  y1="3" 
                                  x2={scale(median)} 
                                  y2="15" 
                                  stroke="#ffffff" 
                                  strokeWidth="1.5" 
                                />
                                
                                <title>{`Min: ${min.toFixed(2)}\nQ1: ${q1.toFixed(2)}\nMedian: ${median.toFixed(2)}\nQ3: ${q3.toFixed(2)}\nMax: ${max.toFixed(2)}`}</title>
                              </svg>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Subtab content 4: Pairplot Matrix */}
                {activePlotsSubTab === 'pairplot' && (
                  <div className="space-y-3">
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Pairwise feature-to-feature grid of scatter & distribution plots. Hover to inspect, click any cell to set active coordinates.
                    </p>

                    <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-900 flex flex-col gap-1.5">
                      <div className="grid grid-cols-4 gap-1.5">
                        {['danceability', 'energy', 'valence', 'acousticness'].map((featX) => {
                          const fXObj = AUDIO_FEATURES.find(f => f.id === featX);
                          return (
                            <div key={featX} className="text-[7.5px] font-mono text-slate-500 font-extrabold uppercase text-center truncate">
                              {fXObj?.name.substring(0, 5)}
                            </div>
                          );
                        })}
                      </div>

                      <div className="space-y-1.5">
                        {['danceability', 'energy', 'valence', 'acousticness'].map((featY) => (
                          <div key={featY} className="grid grid-cols-4 gap-1.5">
                            {['danceability', 'energy', 'valence', 'acousticness'].map((featX) => {
                              const isDiagonal = featX === featY;
                              
                              return (
                                <div
                                  key={featX}
                                  onClick={() => {
                                    setXAxisFeature(featX);
                                    setYAxisFeature(featY);
                                  }}
                                  onMouseEnter={() => setHoveredPairCell({ x: featX, y: featY })}
                                  onMouseLeave={() => setHoveredPairCell(null)}
                                  className={`aspect-square rounded border cursor-pointer transition-all hover:scale-105 overflow-hidden flex flex-col items-center justify-center ${
                                    isDiagonal 
                                      ? 'bg-slate-900/40 border-slate-800' 
                                      : 'bg-slate-950 border-slate-900/60 hover:border-emerald-500/40'
                                  }`}
                                >
                                  <svg className="w-full h-full" viewBox="0 0 45 45">
                                    {isDiagonal ? (
                                      // Render KDE wave for diagonal
                                      (() => {
                                        const bins = Array(6).fill(0);
                                        SPOTIFY_TRACKS.forEach(t => {
                                          const val = getFeatureValue(t, featX);
                                          const binIdx = Math.min(5, Math.floor(val * 6));
                                          bins[binIdx]++;
                                        });
                                        const maxVal = Math.max(...bins, 1);
                                        const points = bins.map((count, idx) => {
                                          const x = (idx / 5) * 45;
                                          const y = 45 - (count / maxVal) * 35;
                                          return `${x},${y}`;
                                        }).join(' ');
                                        
                                        return (
                                          <polygon 
                                            points={`0,45 ${points} 45,45`} 
                                            fill="rgba(16, 185, 129, 0.15)" 
                                            stroke="rgba(16, 185, 129, 0.6)" 
                                            strokeWidth="1"
                                          />
                                        );
                                      })()
                                    ) : (
                                      // Render Mini Scatter points
                                      (() => {
                                        // Sample a subset for lightweight SVG performance
                                        const samples = SPOTIFY_TRACKS.slice(0, 25);
                                        return samples.map(t => {
                                          const xVal = getFeatureValue(t, featX);
                                          const yVal = getFeatureValue(t, featY);
                                          const cx = 4 + xVal * 37;
                                          const cy = 41 - yVal * 37;
                                          const trackCluster = clusters.find(c => c.tracks.some(tr => tr.id === t.id));
                                          const color = trackCluster ? trackCluster.color : '#64748b';
                                          
                                          return (
                                            <circle 
                                              key={t.id} 
                                              cx={cx} 
                                              cy={cy} 
                                              r="1.2" 
                                              fill={color} 
                                            />
                                          );
                                        });
                                      })()
                                    )}
                                  </svg>
                                </div>
                              );
                            })}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Pairplot interaction hover indicator */}
                    <div className="h-9 bg-slate-950/40 border border-slate-900 rounded-lg p-1.5 flex items-center justify-center text-[9px] text-center font-mono">
                      {hoveredPairCell ? (
                        <div className="text-slate-300">
                          Inspect: <span className="text-emerald-400 font-bold capitalize">{hoveredPairCell.x}</span>
                          <span className="text-slate-500"> vs </span>
                          <span className="text-emerald-400 font-bold capitalize">{hoveredPairCell.y}</span>
                          <span className="text-slate-500"> (Click to set)</span>
                        </div>
                      ) : (
                        <span className="text-slate-600 italic">Click cell to select axes</span>
                      )}
                    </div>
                  </div>
                )}

                {/* Subtab content 5: Heatmap Correlation */}
                {activePlotsSubTab === 'heatmap' && (
                  <div className="space-y-3">
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Pearson correlation matrix across features. Hover a cell to view coefficient.
                    </p>
                    
                    {/* Heatmap Grid */}
                    <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-900/80">
                      {/* X axis labels (top) */}
                      <div className="grid grid-cols-6 gap-1 mb-1 text-center">
                        <div />
                        {AUDIO_FEATURES.map(feat => (
                          <div key={feat.id} className="text-[7.5px] font-mono text-slate-500 font-bold truncate capitalize" title={feat.name}>
                            {feat.name.substring(0, 4)}
                          </div>
                        ))}
                      </div>

                      {/* Heatmap Rows */}
                      <div className="space-y-1">
                        {AUDIO_FEATURES.map((featY) => (
                          <div key={featY.id} className="grid grid-cols-6 gap-1 items-center">
                            {/* Y axis label */}
                            <div className="text-[7.5px] font-mono text-slate-500 font-bold text-right truncate capitalize pr-1" title={featY.name}>
                              {featY.name.substring(0, 4)}
                            </div>

                            {/* Cells */}
                            {AUDIO_FEATURES.map((featX) => {
                              const correlation = calculateCorrelation(featY.id, featX.id);
                              
                              // Color scale
                              let bgStyle = '';
                              if (featY.id === featX.id) {
                                bgStyle = 'rgba(16, 185, 129, 0.95)'; // Perfect diagonal
                              } else if (correlation > 0) {
                                const intensity = Math.min(0.9, Math.max(0.15, correlation * 1.1));
                                bgStyle = `rgba(16, 185, 129, ${intensity})`; // Emerald
                              } else {
                                const intensity = Math.min(0.9, Math.max(0.15, Math.abs(correlation) * 1.1));
                                bgStyle = `rgba(244, 63, 94, ${intensity})`; // Rose
                              }

                              return (
                                <div
                                  key={featX.id}
                                  onMouseEnter={() => setHoveredCorrelation({ f1: featY.name, f2: featX.name, val: correlation })}
                                  onMouseLeave={() => setHoveredCorrelation(null)}
                                  className="aspect-square rounded flex items-center justify-center text-[9px] font-mono transition-all duration-150 relative cursor-crosshair hover:scale-105 hover:ring-1 hover:ring-white/30 text-slate-100 font-semibold"
                                  style={{ backgroundColor: bgStyle }}
                                >
                                  {correlation.toFixed(2)}
                                </div>
                              );
                            })}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Correlation tooltip display */}
                    <div className="h-10 bg-slate-950/40 border border-slate-900 rounded-lg p-2 flex items-center justify-center text-[9.5px] text-center font-mono">
                      {hoveredCorrelation ? (
                        <div className="text-slate-300">
                          <span className="text-emerald-400 font-bold">{hoveredCorrelation.f1}</span>
                          <span className="text-slate-500"> × </span>
                          <span className="text-emerald-400 font-bold">{hoveredCorrelation.f2}</span>
                          <span className="text-slate-500"> = </span>
                          <span className={hoveredCorrelation.val >= 0 ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
                            {hoveredCorrelation.val >= 0 ? '+' : ''}{hoveredCorrelation.val.toFixed(3)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-600 italic">Hover cells to reveal correlation details</span>
                      )}
                    </div>
                  </div>
                )}

                {/* Subtab content 6: Averages/Centroids Bar */}
                {activePlotsSubTab === 'averages' && (
                  <div className="space-y-4">
                    <p className="text-[10px] text-slate-400 leading-normal">
                      High-dimensional centroid parameters of the actively highlighted segment group.
                    </p>

                    {selectedClusterId !== null && clusters[selectedClusterId] ? (
                      <div className="space-y-3 p-3 bg-slate-950/40 rounded-xl border border-slate-900">
                        <div className="flex items-center gap-2 border-b border-slate-900 pb-2">
                          <span className="text-xl">{clusters[selectedClusterId].emoji}</span>
                          <div className="min-w-0">
                            <h4 className="text-[11px] font-bold text-slate-200 truncate">{clusters[selectedClusterId].name} Centroid</h4>
                            <span className="text-[8px] font-mono text-slate-500 uppercase">Normalized Dimensions</span>
                          </div>
                        </div>

                        <div className="space-y-2.5 pt-1">
                          {Object.entries(clusters[selectedClusterId].centroid).map(([feat, val]) => {
                            const valNum = val as number;
                            const featObj = AUDIO_FEATURES.find(f => f.id === feat);
                            const normVal = feat === 'tempo' ? Math.max(0, Math.min(1, (valNum - 60) / 120)) : valNum;
                            return (
                              <div key={feat} className="space-y-1">
                                <div className="flex justify-between text-[9px] font-mono">
                                  <span className="text-slate-400 capitalize">{featObj?.name || feat}</span>
                                  <span className="text-emerald-400 font-bold">
                                    {feat === 'tempo' ? `${Math.round(valNum)} BPM` : valNum.toFixed(3)}
                                  </span>
                                </div>
                                <div className="h-1.5 bg-slate-950 border border-slate-900 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full rounded-full transition-all duration-500"
                                    style={{ 
                                      width: `${normVal * 100}%`,
                                      backgroundColor: clusters[selectedClusterId].color 
                                    }}
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center p-4 text-[10px] text-slate-500">
                        Please select a segment below to view centroid values.
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              // Dataset table Explorer Tab
              <div className="space-y-3">
                {/* Search and Filters */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={datasetSearch}
                    onChange={(e) => setDatasetSearch(e.target.value)}
                    placeholder="Search song or artist..."
                    className="flex-1 px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-950 text-[10px] text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <select
                    value={datasetClusterFilter}
                    onChange={(e) => setDatasetClusterFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[10px] text-slate-300 focus:outline-none cursor-pointer"
                  >
                    <option value="all">All Clusters</option>
                    {clusters.map((cluster) => (
                      <option key={cluster.id} value={cluster.id}>
                        {cluster.emoji} #{cluster.id + 1}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Dataset list container */}
                <div className="max-h-60 overflow-y-auto border border-slate-900 bg-slate-950/40 rounded-xl divide-y divide-slate-950/70 scrollbar-thin">
                  {(() => {
                    const filteredTracks = SPOTIFY_TRACKS.filter((track) => {
                      // search match
                      const searchMatch = 
                        track.title.toLowerCase().includes(datasetSearch.toLowerCase()) ||
                        track.artist.toLowerCase().includes(datasetSearch.toLowerCase()) ||
                        track.genre.toLowerCase().includes(datasetSearch.toLowerCase());
                      
                      if (!searchMatch) return false;

                      // cluster filter match
                      if (datasetClusterFilter === 'all') return true;
                      
                      const trackCluster = clusters.find(c => c.tracks.some(t => t.id === track.id));
                      return trackCluster?.id.toString() === datasetClusterFilter;
                    });

                    if (filteredTracks.length === 0) {
                      return (
                        <div className="p-6 text-center text-slate-600 text-[10px] font-mono">
                          No matching tracks found in pool
                        </div>
                      );
                    }

                    return filteredTracks.map((track) => {
                      const trackCluster = clusters.find(c => c.tracks.some(t => t.id === track.id));
                      const isTrackActive = activeTrack?.id === track.id;

                      return (
                        <div 
                          key={track.id}
                          className={`p-2 flex items-center justify-between gap-2.5 transition-all hover:bg-slate-900/40 ${
                            isTrackActive ? 'bg-emerald-500/5' : ''
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0 flex-1">
                            {/* Small colored dot / play */}
                            <button
                              onClick={() => handleTrackPlayToggle(track)}
                              className="w-5 h-5 rounded-full bg-slate-900 hover:bg-slate-800/80 border border-slate-800 flex items-center justify-center shrink-0 cursor-pointer transition-all"
                            >
                              {isTrackActive && isPlaying ? (
                                <Pause size={8} className="fill-emerald-400 text-emerald-400 stroke-[3]" />
                              ) : (
                                <Play size={8} className="fill-slate-400 text-slate-400 ml-0.5" />
                              )}
                            </button>

                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className={`text-[10px] font-bold truncate block ${isTrackActive ? 'text-emerald-400' : 'text-slate-200'}`}>
                                  {track.title}
                                </span>
                              </div>
                              <span className="text-[8px] text-slate-500 block truncate leading-tight">
                                {track.artist} • <span className="italic">{track.genre}</span>
                              </span>
                            </div>
                          </div>

                          {/* Cluster badge info */}
                          {trackCluster && (
                            <button
                              onClick={() => setSelectedClusterId(trackCluster.id)}
                              className="px-2 py-0.5 rounded-full text-[8px] font-mono border font-semibold hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-1 shrink-0"
                              style={{ 
                                backgroundColor: `${trackCluster.color}15`, 
                                borderColor: `${trackCluster.color}40`,
                                color: trackCluster.color
                              }}
                            >
                              <span>{trackCluster.emoji}</span>
                              <span>#{trackCluster.id + 1}</span>
                            </button>
                          )}
                        </div>
                      );
                    });
                  })()}
                </div>
              </div>
            )}
          </div>
        </section>

        {/* RIGHT COLUMN: Vibe Matcher & Current Segment Playlist (3 cols) */}
        <section className="lg:col-span-3 flex flex-col gap-6">
          
          {/* Active Segment Selector Grid */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Generated Segments</span>
            <div className="grid grid-cols-2 gap-3">
              {clusters.map((cluster) => {
                const isSelected = selectedClusterId === cluster.id;
                const isMatched = matchedClusterId === cluster.id;

                return (
                  <button
                    key={cluster.id}
                    onClick={() => setSelectedClusterId(cluster.id)}
                    className={`text-left p-3.5 rounded-xl border relative overflow-hidden transition-all duration-200 cursor-pointer ${
                      isSelected 
                        ? 'bg-slate-900 border-slate-700 shadow-lg ring-1 ring-emerald-500/20' 
                        : 'bg-slate-900/30 border-slate-800/60 hover:bg-slate-900/50 hover:border-slate-800'
                    }`}
                  >
                    {/* Visual color slice indicator */}
                    <div 
                      className="absolute top-0 left-0 bottom-0 w-1.5" 
                      style={{ backgroundColor: cluster.color }}
                    />

                    {isMatched && (
                      <div className="absolute top-2 right-2 flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                      </div>
                    )}

                    <div className="pl-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-lg">{cluster.emoji}</span>
                        <h3 className="text-xs font-bold text-slate-200 truncate">{cluster.name}</h3>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono mt-1.5 block">
                        {cluster.tracks.length} tracks matched
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Card 2: Current Segment Playlist & Mini Player */}
          {selectedClusterId !== null && clusters[selectedClusterId] && (
            <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl shadow-xl flex flex-col overflow-hidden flex-1 min-h-[380px]">
              
              {/* Segment Profile Header */}
              <div className="p-4 border-b border-slate-800 bg-slate-900/40 space-y-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-xl">{clusters[selectedClusterId].emoji}</span>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-xs font-bold text-slate-100 truncate">
                      {clusters[selectedClusterId].name}
                    </h3>
                    <span className="text-[9px] text-emerald-400 font-bold uppercase tracking-wider block">
                      Segment Playlist ({clusters[selectedClusterId].tracks.length} Tracks)
                    </span>
                  </div>
                </div>
                
                <p className="text-[10px] text-slate-400 leading-normal">
                  {clusters[selectedClusterId].description}
                </p>

                <div className="flex flex-wrap gap-1 text-[9px] text-slate-400">
                  <span className="bg-slate-950 border border-slate-850 px-2 py-0.5 rounded-md font-medium">
                    Best for: <strong>{clusters[selectedClusterId].bestFor}</strong>
                  </span>
                </div>
              </div>

              {/* Tracks List inside Segment */}
              <div className="flex-1 overflow-y-auto max-h-[220px] scrollbar-thin p-3 space-y-2">
                {clusters[selectedClusterId].tracks.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-4 text-slate-500">
                    <ListMusic size={24} className="stroke-[1.5] mb-1.5 opacity-60" />
                    <span className="text-[10px] font-bold">No Tracks Clustered</span>
                    <span className="text-[9px]">Try adjusting target segments or feature options.</span>
                  </div>
                ) : (
                  clusters[selectedClusterId].tracks.map((track) => {
                    const isTrackActive = activeTrack?.id === track.id;
                    return (
                      <button
                        key={track.id}
                        onClick={() => handleTrackPlayToggle(track)}
                        className={`w-full text-left p-2.5 rounded-xl border flex items-center gap-3 transition-all cursor-pointer ${
                          isTrackActive 
                            ? 'bg-emerald-500/10 border-emerald-500/20 shadow-neon-emerald' 
                            : 'bg-slate-950/40 border-slate-900 hover:bg-slate-900/50 hover:border-slate-800'
                        }`}
                      >
                        {/* Album Art Mini Mockup */}
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-tr ${track.albumArtColor} shrink-0 flex items-center justify-center shadow-inner relative`}>
                          {isTrackActive && isPlaying ? (
                            <div className="absolute inset-0 flex items-end justify-center pb-2.5 gap-[2px]">
                              <span className="w-[2px] bg-slate-950 animate-bar-1" />
                              <span className="w-[2px] bg-slate-950 animate-bar-2" />
                              <span className="w-[2px] bg-slate-950 animate-bar-3" />
                            </div>
                          ) : (
                            <Music size={12} className="text-white/80" />
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-1.5">
                            <span className={`text-[11px] font-bold truncate ${isTrackActive ? 'text-emerald-400' : 'text-slate-200'}`}>
                              {track.title}
                            </span>
                            <span className="text-[9px] font-mono text-slate-500 shrink-0">
                              {track.tempo} BPM
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block truncate mt-0.5">
                            {track.artist}
                          </span>
                        </div>
                      </button>
                    );
                  })
                )}
              </div>

              {/* Music Player Footer panel */}
              {activeTrack && (
                <div className="bg-slate-900 border-t border-slate-800 p-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${activeTrack.albumArtColor} shrink-0 flex items-center justify-center shadow-lg relative overflow-hidden`}>
                      <Disc size={20} className={`text-white/85 ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
                    </div>

                    <div className="min-w-0 flex-1">
                      <span className="text-xs font-bold text-slate-100 truncate block">
                        {activeTrack.title}
                      </span>
                      <span className="text-[10px] text-slate-400 block truncate">
                        {activeTrack.artist}
                      </span>
                    </div>

                    {/* Play/Pause controls */}
                    <button 
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="p-2.5 rounded-full bg-emerald-500 text-slate-950 hover:bg-emerald-400 hover:scale-105 active:scale-95 transition-all cursor-pointer shadow-lg shadow-emerald-500/10 shrink-0"
                    >
                      {isPlaying ? <Pause size={13} className="fill-slate-950 stroke-[3]" /> : <Play size={13} className="fill-slate-950 stroke-[3] ml-0.5" />}
                    </button>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="relative h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="absolute top-0 bottom-0 left-0 bg-emerald-500 rounded-full transition-all duration-300" 
                        style={{ width: `${playerProgress}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[8px] font-mono text-slate-500">
                      <span>0:{playerProgress < 10 ? `0${Math.floor(playerProgress / 2)}` : Math.floor(playerProgress / 2)}</span>
                      <span>Audio Preview Playing</span>
                      <span>2:30</span>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

        </section>

      </main>
      </div>
    </div>
  );
}
