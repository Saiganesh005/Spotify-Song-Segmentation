export interface Track {
  id: string;
  title: string;
  artist: string;
  genre: string;
  danceability: number; // 0 to 1
  energy: number;       // 0 to 1
  valence: number;      // 0 to 1 (musical positiveness)
  acousticness: number; // 0 to 1
  tempo: number;        // BPM (60 to 180)
  popularity: number;   // 0 to 100
  albumArtColor: string;// For visual aesthetics
}

export const SPOTIFY_TRACKS: Track[] = [
  // Pop
  { id: '1', title: 'Blinding Lights', artist: 'The Weeknd', genre: 'Pop', danceability: 0.51, energy: 0.80, valence: 0.65, acousticness: 0.001, tempo: 171, popularity: 95, albumArtColor: 'from-amber-500 to-red-600' },
  { id: '2', title: 'As It Was', artist: 'Harry Styles', genre: 'Pop', danceability: 0.52, energy: 0.73, valence: 0.66, acousticness: 0.34, tempo: 174, popularity: 92, albumArtColor: 'from-sky-400 to-indigo-600' },
  { id: '3', title: 'Levitating', artist: 'Dua Lipa', genre: 'Pop', danceability: 0.83, energy: 0.82, valence: 0.91, acousticness: 0.02, tempo: 103, popularity: 88, albumArtColor: 'from-pink-500 to-purple-600' },
  { id: '4', title: 'Bad Guy', artist: 'Billie Eilish', genre: 'Pop', danceability: 0.70, energy: 0.43, valence: 0.56, acousticness: 0.33, tempo: 135, popularity: 87, albumArtColor: 'from-emerald-600 to-teal-900' },
  { id: '5', title: 'Cruel Summer', artist: 'Taylor Swift', genre: 'Pop', danceability: 0.55, energy: 0.70, valence: 0.56, acousticness: 0.12, tempo: 170, popularity: 94, albumArtColor: 'from-pink-400 to-amber-300' },

  // Hip-Hop / Rap
  { id: '6', title: 'Sicko Mode', artist: 'Travis Scott', genre: 'Hip-Hop', danceability: 0.83, energy: 0.73, valence: 0.45, acousticness: 0.01, tempo: 155, popularity: 89, albumArtColor: 'from-red-800 to-slate-900' },
  { id: '7', title: 'Gods Plan', artist: 'Drake', genre: 'Hip-Hop', danceability: 0.75, energy: 0.45, valence: 0.36, acousticness: 0.03, tempo: 77, popularity: 88, albumArtColor: 'from-blue-600 to-cyan-500' },
  { id: '8', title: 'HUMBLE.', artist: 'Kendrick Lamar', genre: 'Hip-Hop', danceability: 0.91, energy: 0.81, valence: 0.42, acousticness: 0.0003, tempo: 150, popularity: 86, albumArtColor: 'from-slate-800 to-neutral-900' },
  { id: '9', title: 'Industry Baby', artist: 'Lil Nas X & Jack Harlow', genre: 'Hip-Hop', danceability: 0.74, energy: 0.69, valence: 0.89, acousticness: 0.02, tempo: 150, popularity: 84, albumArtColor: 'from-pink-600 to-rose-500' },
  { id: '10', title: 'Lose Yourself', artist: 'Eminem', genre: 'Hip-Hop', danceability: 0.69, energy: 0.74, valence: 0.06, acousticness: 0.01, tempo: 86, popularity: 85, albumArtColor: 'from-zinc-700 to-zinc-900' },

  // Rock / Indie
  { id: '11', title: 'Mr. Brightside', artist: 'The Killers', genre: 'Rock', danceability: 0.35, energy: 0.93, valence: 0.24, acousticness: 0.001, tempo: 148, popularity: 86, albumArtColor: 'from-yellow-600 to-amber-800' },
  { id: '12', title: 'Do I Wanna Know?', artist: 'Arctic Monkeys', genre: 'Rock', danceability: 0.55, energy: 0.53, valence: 0.40, acousticness: 0.19, tempo: 85, popularity: 88, albumArtColor: 'from-slate-700 to-slate-950' },
  { id: '13', title: 'Bohemian Rhapsody', artist: 'Queen', genre: 'Rock', danceability: 0.39, energy: 0.40, valence: 0.23, acousticness: 0.27, tempo: 144, popularity: 85, albumArtColor: 'from-purple-900 to-indigo-950' },
  { id: '14', title: 'Smells Like Teen Spirit', artist: 'Nirvana', genre: 'Rock', danceability: 0.50, energy: 0.82, valence: 0.44, acousticness: 0.0001, tempo: 117, popularity: 84, albumArtColor: 'from-neutral-700 to-yellow-900' },
  { id: '15', title: 'Sweater Weather', artist: 'The Neighbourhood', genre: 'Indie', danceability: 0.61, energy: 0.76, valence: 0.40, acousticness: 0.05, tempo: 124, popularity: 89, albumArtColor: 'from-teal-800 to-slate-900' },

  // Electronic / Dance / EDM
  { id: '16', title: 'Wake Me Up', artist: 'Avicii', genre: 'Electronic', danceability: 0.53, energy: 0.78, valence: 0.64, acousticness: 0.003, tempo: 124, popularity: 83, albumArtColor: 'from-orange-500 to-amber-600' },
  { id: '17', title: 'Closer', artist: 'The Chainsmokers', genre: 'Electronic', danceability: 0.75, energy: 0.52, valence: 0.66, acousticness: 0.41, tempo: 95, popularity: 85, albumArtColor: 'from-cyan-500 to-blue-600' },
  { id: '18', title: 'One More Time', artist: 'Daft Punk', genre: 'Electronic', danceability: 0.61, energy: 0.69, valence: 0.48, acousticness: 0.04, tempo: 123, popularity: 78, albumArtColor: 'from-pink-500 to-yellow-500' },
  { id: '19', title: 'Strobe', artist: 'deadmau5', genre: 'Electronic', danceability: 0.56, energy: 0.69, valence: 0.12, acousticness: 0.01, tempo: 128, popularity: 61, albumArtColor: 'from-violet-800 to-fuchsia-900' },
  { id: '20', title: 'Lean On', artist: 'Major Lazer & DJ Snake', genre: 'Electronic', danceability: 0.72, energy: 0.81, valence: 0.55, acousticness: 0.003, tempo: 108, popularity: 77, albumArtColor: 'from-lime-500 to-emerald-600' },

  // Jazz & Blues
  { id: '21', title: 'Take Five', artist: 'Dave Brubeck', genre: 'Jazz', danceability: 0.45, energy: 0.32, valence: 0.51, acousticness: 0.63, tempo: 174, popularity: 69, albumArtColor: 'from-amber-800 to-amber-950' },
  { id: '22', title: 'Come Away With Me', artist: 'Norah Jones', genre: 'Jazz', danceability: 0.54, energy: 0.16, valence: 0.32, acousticness: 0.88, tempo: 80, popularity: 78, albumArtColor: 'from-yellow-200 to-amber-400' },
  { id: '23', title: 'My Funny Valentine', artist: 'Chet Baker', genre: 'Jazz', danceability: 0.32, energy: 0.09, valence: 0.28, acousticness: 0.94, tempo: 81, popularity: 64, albumArtColor: 'from-blue-900 to-neutral-900' },
  { id: '24', title: 'Fly Me To The Moon', artist: 'Frank Sinatra', genre: 'Jazz', danceability: 0.61, energy: 0.25, valence: 0.50, acousticness: 0.72, tempo: 119, popularity: 82, albumArtColor: 'from-indigo-800 to-slate-900' },
  { id: '25', title: 'Feeling Good', artist: 'Nina Simone', genre: 'Jazz', danceability: 0.44, energy: 0.31, valence: 0.22, acousticness: 0.84, tempo: 115, popularity: 76, albumArtColor: 'from-purple-800 to-neutral-900' },

  // Classical / Ambient / Chill
  { id: '26', title: 'Clair de Lune', artist: 'Claude Debussy', genre: 'Classical', danceability: 0.21, energy: 0.01, valence: 0.05, acousticness: 0.99, tempo: 64, popularity: 73, albumArtColor: 'from-teal-900 to-cyan-950' },
  { id: '27', title: 'Gymnopédie No. 1', artist: 'Erik Satie', genre: 'Classical', danceability: 0.31, energy: 0.05, valence: 0.12, acousticness: 0.99, tempo: 75, popularity: 74, albumArtColor: 'from-cyan-900 to-sky-950' },
  { id: '28', title: 'Experience', artist: 'Ludovico Einaudi', genre: 'Classical', danceability: 0.45, energy: 0.34, valence: 0.04, acousticness: 0.95, tempo: 94, popularity: 81, albumArtColor: 'from-indigo-900 to-purple-950' },
  { id: '29', title: 'Spiegel im Spiegel', artist: 'Arvo Pärt', genre: 'Classical', danceability: 0.12, energy: 0.005, valence: 0.03, acousticness: 0.99, tempo: 70, popularity: 60, albumArtColor: 'from-blue-950 to-neutral-900' },
  { id: '30', title: 'Nuvole Bianche', artist: 'Ludovico Einaudi', genre: 'Classical', danceability: 0.34, energy: 0.14, valence: 0.08, acousticness: 0.99, tempo: 138, popularity: 78, albumArtColor: 'from-slate-700 to-zinc-900' },

  // R&B / Soul / Acoustic
  { id: '31', title: 'Redbone', artist: 'Childish Gambino', genre: 'R&B', danceability: 0.74, energy: 0.35, valence: 0.57, acousticness: 0.17, tempo: 160, popularity: 84, albumArtColor: 'from-pink-800 to-amber-900' },
  { id: '32', title: 'Thinking Out Loud', artist: 'Ed Sheeran', genre: 'Acoustic', danceability: 0.78, energy: 0.45, valence: 0.59, acousticness: 0.47, tempo: 79, popularity: 86, albumArtColor: 'from-sky-500 to-yellow-600' },
  { id: '33', title: 'Ocean Eyes', artist: 'Billie Eilish', genre: 'Pop', danceability: 0.51, energy: 0.08, valence: 0.16, acousticness: 0.81, tempo: 145, popularity: 83, albumArtColor: 'from-teal-900 to-emerald-950' },
  { id: '34', title: 'Adorn', artist: 'Miguel', genre: 'R&B', danceability: 0.67, energy: 0.44, valence: 0.52, acousticness: 0.24, tempo: 90, popularity: 72, albumArtColor: 'from-indigo-500 to-purple-600' },
  { id: '35', title: 'Superstition', artist: 'Stevie Wonder', genre: 'Soul', danceability: 0.82, energy: 0.66, valence: 0.92, acousticness: 0.09, tempo: 100, popularity: 79, albumArtColor: 'from-amber-600 to-red-600' },

  // Latin / Reggaeton
  { id: '36', title: 'Despacito', artist: 'Luis Fonsi & Daddy Yankee', genre: 'Latin', danceability: 0.82, energy: 0.79, valence: 0.82, acousticness: 0.20, tempo: 89, popularity: 82, albumArtColor: 'from-yellow-500 to-orange-600' },
  { id: '37', title: 'Dakiti', artist: 'Bad Bunny & Jhayco', genre: 'Latin', danceability: 0.73, energy: 0.57, valence: 0.51, acousticness: 0.40, tempo: 110, popularity: 84, albumArtColor: 'from-teal-500 to-cyan-600' },
  { id: '38', title: 'Mi Gente', artist: 'J Balvin & Willy William', genre: 'Latin', danceability: 0.76, energy: 0.73, valence: 0.71, acousticness: 0.01, tempo: 105, popularity: 79, albumArtColor: 'from-pink-500 to-orange-500' },
  { id: '39', title: 'Pepas', artist: 'Farruko', genre: 'Latin', danceability: 0.76, energy: 0.77, valence: 0.44, acousticness: 0.01, tempo: 130, popularity: 81, albumArtColor: 'from-cyan-400 to-blue-500' },
  { id: '40', title: 'Tusa', artist: 'KAROL G & Nicki Minaj', genre: 'Latin', danceability: 0.80, energy: 0.72, valence: 0.57, acousticness: 0.30, tempo: 101, popularity: 78, albumArtColor: 'from-purple-500 to-pink-500' },

  // Cinematic / Electronic Chill
  { id: '41', title: 'Intro', artist: 'The xx', genre: 'Indie', danceability: 0.62, energy: 0.78, valence: 0.24, acousticness: 0.14, tempo: 120, popularity: 78, albumArtColor: 'from-gray-800 to-neutral-900' },
  { id: '42', title: 'Midnight City', artist: 'M83', genre: 'Electronic', danceability: 0.44, energy: 0.78, valence: 0.52, acousticness: 0.01, tempo: 105, popularity: 81, albumArtColor: 'from-blue-700 to-fuchsia-800' },
  { id: '43', title: 'Teardrop', artist: 'Massive Attack', genre: 'Electronic', danceability: 0.62, energy: 0.31, valence: 0.31, acousticness: 0.34, tempo: 77, popularity: 71, albumArtColor: 'from-zinc-800 to-zinc-950' },
  { id: '44', title: 'First Mind', artist: 'Nick Mulvey', genre: 'Indie', danceability: 0.69, energy: 0.41, valence: 0.68, acousticness: 0.73, tempo: 110, popularity: 63, albumArtColor: 'from-emerald-700 to-amber-700' },
  { id: '45', title: 'Riverside', artist: 'Agnes Obel', genre: 'Chamber Pop', danceability: 0.49, energy: 0.08, valence: 0.19, acousticness: 0.98, tempo: 125, popularity: 68, albumArtColor: 'from-sky-950 to-indigo-950' }
];

export const AUDIO_FEATURES = [
  { id: 'danceability', name: 'Danceability', desc: 'How suitable a track is for dancing (tempo, rhythm stability, beat strength, overall regularity).' },
  { id: 'energy', name: 'Energy', desc: 'Perceptual measure of intensity, activity, noise, and power (e.g. fast, loud, bouncy).' },
  { id: 'valence', name: 'Valence', desc: 'Musical positiveness (high valence = happy, cheerful; low valence = sad, angry).' },
  { id: 'acousticness', name: 'Acousticness', desc: 'A confidence measure from 0 to 1 of whether the track is acoustic.' },
  { id: 'tempo', name: 'Tempo', desc: 'The overall estimated tempo of a track in beats per minute (BPM).' }
];
