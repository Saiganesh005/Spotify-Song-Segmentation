import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const parseJsonBody = (req: any): Promise<any> => {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk: any) => { body += chunk; });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
  });
};

const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("Warning: GEMINI_API_KEY is not configured.");
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

function apiMiddlewarePlugin() {
  return {
    name: 'api-middleware-plugin',
    configureServer(server: any) {
      server.middlewares.use(async (req: any, res: any, next: any) => {
        if (!req.url.startsWith('/api/')) {
          return next();
        }

        try {
          const ai = getGeminiClient();
          if (!ai) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'GEMINI_API_KEY is not configured on the server. Please check Settings > Secrets.' }));
            return;
          }

          if (req.url === '/api/chat' && req.method === 'POST') {
            const body = await parseJsonBody(req);
            const { contents, systemInstruction } = body;

            if (!contents || !Array.isArray(contents)) {
              res.writeHead(400, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'contents array is required.' }));
              return;
            }

            const response = await ai.models.generateContent({
              model: 'gemini-3.5-flash',
              contents: contents,
              config: {
                systemInstruction: systemInstruction || 'You are a helpful assistant.',
              },
            });

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ text: response.text }));
            return;
          }

          if (req.url === '/api/optimize-prompt' && req.method === 'POST') {
            const body = await parseJsonBody(req);
            const { prompt } = body;

            if (!prompt) {
              res.writeHead(400, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'prompt is required.' }));
              return;
            }

            const sysInstruction = `You are an expert prompt engineer. Your goal is to optimize the user's provided prompt to make it highly effective when used with Gemini or other large language models.
Format your response using Markdown, following this structured layout:
1. **Clear Objectives**: Explain what the optimized prompt intends to achieve.
2. **The Optimized Prompt**: Provide the precise, ready-to-copy prompt inside a clear markdown code block. Include sections for context, guidelines, inputs, and desired output formats.
3. **Key Enhancements**: Briefly bullet-point what was added (e.g., role-play framing, structural boundaries, examples, negative constraints) and why.`;

            const response = await ai.models.generateContent({
              model: 'gemini-3.5-flash',
              contents: `Please optimize the following prompt:\n\n"${prompt}"`,
              config: {
                systemInstruction: sysInstruction,
              },
            });

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ optimizedPrompt: response.text }));
            return;
          }

          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Endpoint not found.' }));
        } catch (error: any) {
          console.error('API Dev Middleware Error:', error);
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: error.message || 'Internal server error' }));
        }
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), apiMiddlewarePlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
