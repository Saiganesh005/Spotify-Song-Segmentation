import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialize Gemini client safely
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required but missing. Please set it in Settings > Secrets.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Robust content generation helper with exponential backoff retries and model fallbacks
async function generateContentWithFallback(
  ai: GoogleGenAI,
  params: {
    contents: any;
    systemInstruction?: string;
    responseMimeType?: string;
  }
) {
  // Ordered list of models to try. We start with gemini-3.5-flash and fallback to gemini-3.1-flash-lite.
  const models = ['gemini-3.5-flash', 'gemini-3.1-flash-lite'];
  let lastError: any = null;

  for (const model of models) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        console.log(`[Gemini] Requesting model "${model}" - Attempt ${attempt}/3`);
        const response = await ai.models.generateContent({
          model: model,
          contents: params.contents,
          config: {
            systemInstruction: params.systemInstruction || 'You are a helpful assistant.',
            ...(params.responseMimeType ? { responseMimeType: params.responseMimeType } : {}),
          },
        });
        
        if (response && response.text) {
          console.log(`[Gemini] Success using model "${model}" on attempt ${attempt}`);
          return response;
        }
      } catch (error: any) {
        lastError = error;
        console.warn(`[Gemini] Failed attempt ${attempt}/3 for model "${model}":`, error?.message || error);
        
        // Only delay if we are going to retry the same model
        if (attempt < 3) {
          const delayMs = attempt * 800; // brief backoff: 800ms, 1600ms
          await new Promise((resolve) => setTimeout(resolve, delayMs));
        }
      }
    }
  }

  // If both models completely failed after all retries, throw the last error
  throw lastError || new Error('Failed to generate content with Gemini after fallback and retries.');
}

// API Routes
app.post('/api/chat', async (req, res) => {
  try {
    const { contents, systemInstruction } = req.body;
    if (!contents || !Array.isArray(contents)) {
      res.status(400).json({ error: 'contents array is required.' });
      return;
    }

    const ai = getGeminiClient();
    const response = await generateContentWithFallback(ai, {
      contents,
      systemInstruction,
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error('Server /api/chat error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

app.post('/api/optimize-prompt', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      res.status(400).json({ error: 'prompt is required.' });
      return;
    }

    const ai = getGeminiClient();
    const sysInstruction = `You are an expert prompt engineer. Your goal is to optimize the user's provided prompt to make it highly effective when used with Gemini or other large language models.
Format your response using Markdown, following this structured layout:
1. **Clear Objectives**: Explain what the optimized prompt intends to achieve.
2. **The Optimized Prompt**: Provide the precise, ready-to-copy prompt inside a clear markdown code block. Include sections for context, guidelines, inputs, and desired output formats.
3. **Key Enhancements**: Briefly bullet-point what was added (e.g., role-play framing, structural boundaries, examples, negative constraints) and why.`;

    const response = await generateContentWithFallback(ai, {
      contents: `Please optimize the following prompt:\n\n"${prompt}"`,
      systemInstruction: sysInstruction,
    });

    res.json({ optimizedPrompt: response.text });
  } catch (error: any) {
    console.error('Server /api/optimize-prompt error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Serve static files in production
const distPath = path.join(process.cwd(), 'dist');
app.use(express.static(distPath));

// Fallback to index.html for SPA routing
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on port ${PORT}`);
});
